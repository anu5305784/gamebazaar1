import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Layout } from "@/components/Layout";
import { ListingCard } from "@/components/ListingCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import { CURRENCIES, LISTING_TYPES } from "@/lib/format";

export default function Browse() {
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const filters = {
    q: params.get("q") || undefined,
    gameId: params.get("game") ? Number(params.get("game")) : undefined,
    listingType: (params.get("category") as "game_account" | "in_game_currency" | "items_skins" | "game_services" | "gift_cards" | "boosting") || undefined,
    currency: (params.get("currency") as "INR" | "USD" | "EUR" | "GBP" | "RUB" | "UAH") || undefined,
    deliveryMethod: (params.get("delivery") as "manual" | "automatic") || undefined,
    sort: (params.get("sort") as "newest" | "price_asc" | "price_desc" | "popular") || "newest",
    minPrice: params.get("min") ? Number(params.get("min")) : undefined,
    maxPrice: params.get("max") ? Number(params.get("max")) : undefined,
  };
  const { data: games } = trpc.market.games.useQuery();
  const { data: listings, isLoading } = trpc.market.search.useQuery(filters);

  const setParam = (k: string, v: string | null) => {
    const next = new URLSearchParams(params);
    if (v == null || v === "") next.delete(k); else next.set(k, v);
    setParams(next);
  };

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="font-display text-2xl font-bold">Browse listings</h1>

        {/* Filters */}
        <div className="mt-5 grid grid-cols-2 gap-2 md:grid-cols-8">
          <form
            className="col-span-2"
            onSubmit={(e) => { e.preventDefault(); setParam("q", q.trim() || null); }}
          >
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" className="bg-card" />
          </form>
          <Select value={params.get("game") ?? "all"} onValueChange={(v) => setParam("game", v === "all" ? null : v)}>
            <SelectTrigger className="bg-card"><SelectValue placeholder="Game" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All games</SelectItem>
              {games?.map((g) => <SelectItem key={g.id} value={String(g.id)}>{g.name} ({g.activeListings})</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={params.get("category") ?? "all"} onValueChange={(v) => setParam("category", v === "all" ? null : v)}>
            <SelectTrigger className="bg-card"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {LISTING_TYPES.map((item) => <SelectItem key={item.code} value={item.code}>{item.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={params.get("currency") ?? "all"} onValueChange={(v) => setParam("currency", v === "all" ? null : v)}>
            <SelectTrigger className="bg-card"><SelectValue placeholder="Currency" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All currencies</SelectItem>
              {CURRENCIES.map((item) => <SelectItem key={item.code} value={item.code}>{item.code}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={params.get("delivery") ?? "all"} onValueChange={(v) => setParam("delivery", v === "all" ? null : v)}>
            <SelectTrigger className="bg-card"><SelectValue placeholder="Delivery" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any delivery</SelectItem>
              <SelectItem value="automatic">⚡ Automatic</SelectItem>
              <SelectItem value="manual">Manual</SelectItem>
            </SelectContent>
          </Select>
          <Select value={params.get("sort") ?? "newest"} onValueChange={(v) => setParam("sort", v)}>
            <SelectTrigger className="bg-card"><SelectValue placeholder="Sort" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price_asc">Price: low → high</SelectItem>
              <SelectItem value="price_desc">Price: high → low</SelectItem>
              <SelectItem value="popular">Most viewed</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Input placeholder="Min price" type="number" className="bg-card" defaultValue={params.get("min") ?? ""} onBlur={(e) => setParam("min", e.target.value || null)} />
            <Input placeholder="Max price" type="number" className="bg-card" defaultValue={params.get("max") ?? ""} onBlur={(e) => setParam("max", e.target.value || null)} />
          </div>
        </div>

        <p className="mt-4 text-sm text-muted-foreground">{listings ? `${listings.length} listing${listings.length === 1 ? "" : "s"}` : "Loading…"}</p>

        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {isLoading
            ? Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)
            : listings?.map((l) => <ListingCard key={l.id} l={l} />)}
        </div>
        {!isLoading && !listings?.length && (
          <div className="mt-8 rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground">
            No listings match your filters.
            <Button variant="link" onClick={() => setParams({})}>Clear filters</Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
