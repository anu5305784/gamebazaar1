import { TRPCError } from "@trpc/server";
import type { User } from "@db/schema";

// Suspended/banned users may still hold a session cookie; block them from
// mutating actions. Read-only endpoints stay available so they can see the notice.
export function assertActive(user: User) {
  if (user.status === "suspended") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Your account is suspended. Contact support.",
    });
  }
  if (user.status === "banned") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Your account has been banned.",
    });
  }
}
