import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  decimal,
  boolean,
  index,
} from "drizzle-orm/mysql-core";

// ---------- Users ----------
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  passwordHash: varchar("passwordHash", { length: 255 }),
  accountType: mysqlEnum("accountType", ["buyer", "seller", "both"])
    .default("both")
    .notNull(),
  status: mysqlEnum("status", ["active", "suspended", "banned"])
    .default("active")
    .notNull(),
  isVerified: boolean("isVerified").default(false).notNull(),
  bio: text("bio"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ---------- Password reset ----------
export const passwordResetTokens = mysqlTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  codeHash: varchar("codeHash", { length: 255 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ---------- Games ----------
export const games = mysqlTable("games", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  icon: text("icon"),
  banner: text("banner"),
  description: text("description"),
  status: mysqlEnum("status", ["active", "inactive"])
    .default("active")
    .notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Game = typeof games.$inferSelect;

// ---------- Listings ----------
export const listings = mysqlTable(
  "listings",
  {
    id: serial("id").primaryKey(),
    sellerId: bigint("sellerId", { mode: "number", unsigned: true }).notNull(),
    gameId: bigint("gameId", { mode: "number", unsigned: true }).notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    price: decimal("price", { precision: 12, scale: 2 }).notNull(),
    currency: mysqlEnum("currency", ["INR", "USD", "EUR", "GBP", "RUB", "UAH"]).default("INR").notNull(),
    listingType: mysqlEnum("listingType", ["game_account", "in_game_currency", "items_skins", "game_services", "gift_cards", "boosting"]).default("game_account").notNull(),
    description: text("description"),
    accountLevel: varchar("accountLevel", { length: 60 }),
    trophiesRank: varchar("trophiesRank", { length: 120 }),
    skinsItems: text("skinsItems"),
    screenshots: text("screenshots"), // JSON array of URLs
    otherInfo: text("otherInfo"),
    deliveryMethod: mysqlEnum("deliveryMethod", ["manual", "automatic"])
      .default("manual")
      .notNull(),
    // Encrypted (AES-256-GCM) delivery credentials — never exposed via API
    deliveryCredentialsEnc: text("deliveryCredentialsEnc"),
    featured: boolean("featured").default(false).notNull(),
    status: mysqlEnum("status", [
      "pending",
      "active",
      "reserved",
      "sold",
      "rejected",
      "removed",
    ])
      .default("pending")
      .notNull(),
    views: int("views").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    sellerIdx: index("listings_seller_idx").on(t.sellerId),
    gameIdx: index("listings_game_idx").on(t.gameId),
    statusIdx: index("listings_status_idx").on(t.status),
  }),
);

export type Listing = typeof listings.$inferSelect;

// ---------- Orders ----------
export const orders = mysqlTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNo: varchar("orderNo", { length: 32 }).notNull().unique(),
    listingId: bigint("listingId", { mode: "number", unsigned: true }).notNull(),
    buyerId: bigint("buyerId", { mode: "number", unsigned: true }).notNull(),
    sellerId: bigint("sellerId", { mode: "number", unsigned: true }).notNull(),
    price: decimal("price", { precision: 12, scale: 2 }).notNull(),
    feePercent: decimal("feePercent", { precision: 5, scale: 2 }).notNull(),
    platformFee: decimal("platformFee", { precision: 12, scale: 2 }).notNull(),
    sellerAmount: decimal("sellerAmount", { precision: 12, scale: 2 }).notNull(),
    status: mysqlEnum("status", [
      "awaiting_payment", // order created, waiting for buyer payment submission
      "payment_verification", // buyer submitted proof, admin reviewing
      "payment_rejected", // admin rejected, buyer may resubmit
      "payment_verified", // admin approved, deal room open
      "delivered", // seller marked delivered
      "completed", // buyer confirmed received, fee settled
      "disputed",
      "cancelled",
      "refunded",
    ])
      .default("awaiting_payment")
      .notNull(),
    paymentMethod: varchar("paymentMethod", { length: 40 }),
    transactionRef: varchar("transactionRef", { length: 255 }),
    paymentProof: text("paymentProof"),
    paymentNote: text("paymentNote"),
    paymentRejectReason: text("paymentRejectReason"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    paidAt: timestamp("paidAt"),
    verifiedAt: timestamp("verifiedAt"),
    deliveredAt: timestamp("deliveredAt"),
    completedAt: timestamp("completedAt"),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    buyerIdx: index("orders_buyer_idx").on(t.buyerId),
    sellerIdx: index("orders_seller_idx").on(t.sellerId),
    statusIdx: index("orders_status_idx").on(t.status),
  }),
);

export type Order = typeof orders.$inferSelect;

// ---------- Wallets ----------
export const wallets = mysqlTable("wallets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  availableBalance: decimal("availableBalance", { precision: 12, scale: 2 })
    .default("0")
    .notNull(),
  pendingBalance: decimal("pendingBalance", { precision: 12, scale: 2 })
    .default("0")
    .notNull(),
  totalEarnings: decimal("totalEarnings", { precision: 14, scale: 2 })
    .default("0")
    .notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Wallet = typeof wallets.$inferSelect;

// ---------- Wallet transactions ----------
export const walletTransactions = mysqlTable(
  "wallet_transactions",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    orderId: bigint("orderId", { mode: "number", unsigned: true }),
    type: mysqlEnum("type", [
      "sale_credit",
      "withdrawal",
      "refund",
      "adjustment",
    ]).notNull(),
    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
    balanceAfter: decimal("balanceAfter", { precision: 12, scale: 2 }).notNull(),
    note: varchar("note", { length: 255 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ userIdx: index("wtx_user_idx").on(t.userId) }),
);

// ---------- Withdrawals ----------
export const withdrawals = mysqlTable(
  "withdrawals",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
    method: varchar("method", { length: 40 }).notNull(), // upi | airtel | crypto
    destination: varchar("destination", { length: 255 }).notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"])
      .default("pending")
      .notNull(),
    adminNote: text("adminNote"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    processedAt: timestamp("processedAt"),
  },
  (t) => ({ userIdx: index("wd_user_idx").on(t.userId) }),
);

// ---------- Deal room messages ----------
export const messages = mysqlTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    orderId: bigint("orderId", { mode: "number", unsigned: true }).notNull(),
    senderId: bigint("senderId", { mode: "number", unsigned: true }), // null = system
    body: text("body").notNull(),
    attachment: text("attachment"),
    isSystem: boolean("isSystem").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ orderIdx: index("msg_order_idx").on(t.orderId) }),
);

// ---------- Reviews ----------
export const reviews = mysqlTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    orderId: bigint("orderId", { mode: "number", unsigned: true })
      .notNull()
      .unique(),
    reviewerId: bigint("reviewerId", { mode: "number", unsigned: true }).notNull(),
    sellerId: bigint("sellerId", { mode: "number", unsigned: true }).notNull(),
    rating: int("rating").notNull(), // 1-5
    comment: text("comment"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ sellerIdx: index("rev_seller_idx").on(t.sellerId) }),
);

// ---------- Disputes ----------
export const disputes = mysqlTable(
  "disputes",
  {
    id: serial("id").primaryKey(),
    orderId: bigint("orderId", { mode: "number", unsigned: true }).notNull(),
    openedBy: bigint("openedBy", { mode: "number", unsigned: true }).notNull(),
    reason: text("reason").notNull(),
    openerEvidence: text("openerEvidence"),
    response: text("response"),
    responseEvidence: text("responseEvidence"),
    status: mysqlEnum("status", ["open", "under_review", "resolved"])
      .default("open")
      .notNull(),
    resolution: mysqlEnum("resolution", ["refund", "complete", "cancel"]),
    adminNote: text("adminNote"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    resolvedAt: timestamp("resolvedAt"),
  },
  (t) => ({ orderIdx: index("disp_order_idx").on(t.orderId) }),
);

// ---------- Notifications ----------
export const notifications = mysqlTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    body: text("body"),
    link: varchar("link", { length: 255 }),
    isRead: boolean("isRead").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ userIdx: index("notif_user_idx").on(t.userId) }),
);

// ---------- Admin settings (key/value) ----------
export const settings = mysqlTable("settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

// ---------- Audit logs ----------
export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    adminId: bigint("adminId", { mode: "number", unsigned: true }),
    action: varchar("action", { length: 120 }).notNull(),
    targetType: varchar("targetType", { length: 60 }),
    targetId: varchar("targetId", { length: 60 }),
    detail: text("detail"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ adminIdx: index("audit_admin_idx").on(t.adminId) }),
);

// ---------- Credential access logs ----------
export const credentialAccessLogs = mysqlTable("credential_access_logs", {
  id: serial("id").primaryKey(),
  adminId: bigint("adminId", { mode: "number", unsigned: true }).notNull(),
  orderId: bigint("orderId", { mode: "number", unsigned: true }).notNull(),
  listingId: bigint("listingId", { mode: "number", unsigned: true }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderStatus = (typeof orders.status.enumValues)[number];
