import { eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { games, users } from "./schema";
import { hashPassword } from "../api/lib/crypto";
import { ensureWallet } from "../api/lib/helpers";

const GAME_LIST = [
  { name: "Brawl Stars", sortOrder: 1 },
  { name: "Clash of Clans", sortOrder: 2 },
  { name: "Clash Royale", sortOrder: 3 },
  { name: "PUBG Mobile", sortOrder: 4 },
  { name: "BGMI", sortOrder: 5 },
  { name: "Fortnite", sortOrder: 6 },
  { name: "Roblox", sortOrder: 7 },
  { name: "Free Fire", sortOrder: 8 },
  { name: "Genshin Impact", sortOrder: 9 },
  { name: "Call of Duty Mobile", sortOrder: 10 },
  { name: "Minecraft", sortOrder: 11 },
];

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  for (const g of GAME_LIST) {
    const slug = g.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const existing = await db.query.games.findFirst({ where: eq(games.slug, slug) });
    if (!existing) {
      await db.insert(games).values({ ...g, slug, status: "active" });
      console.log(`  + game: ${g.name}`);
    }
  }

  // Create an administrator only when explicit credentials are configured.
  // Never ship a known default admin password to a public deployment.
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (adminEmail && adminPassword && adminPassword.length >= 12) {
    const existingAdmin = await db.query.users.findFirst({
      where: eq(users.unionId, `local:${adminEmail}`),
    });
    if (!existingAdmin) {
      await db.insert(users).values({
        unionId: `local:${adminEmail}`,
        name: "GameBazaar Admin",
        email: adminEmail,
        passwordHash: hashPassword(adminPassword),
        accountType: "both",
        role: "admin",
        isVerified: true,
        lastSignInAt: new Date(),
      });
      console.log("  + admin account created from ADMIN_EMAIL.");
    } else {
      await db.update(users).set({
        name: "GameBazaar Admin",
        email: adminEmail,
        passwordHash: hashPassword(adminPassword),
        accountType: "both",
        role: "admin",
        status: "active",
        isVerified: true,
      }).where(eq(users.id, existingAdmin.id));
      console.log("  + admin account credentials/role updated from environment.");
    }
    const admin = await db.query.users.findFirst({ where: eq(users.unionId, `local:${adminEmail}`) });
    if (admin) await ensureWallet(admin.id);
  } else {
    console.log("  ! Admin seed skipped. Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) to create an admin account.");
  }

  console.log("Done.");
  process.exit(0);
}

seed();
