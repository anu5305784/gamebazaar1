import { z } from "zod";
import { and, desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  disputes,
  listings,
  messages,
  orders,
  reviews,
  users,
  wallets,
  walletTransactions,
} from "@db/schema";
import { ensureWallet, notify } from "./lib/helpers";
import { getFeePercent, splitFee, toPaise, toRupees } from "./lib/settings";
import { assertActive } from "./lib/procedures";
import { rateLimit } from "./lib/ratelimit";

function orderNo(): string {
  const t = Date.now().toString(36).toUpperCase();
  const r = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `GB-${t}-${r}`;
}

async function getOrderForUser(orderId: number, user: { id: number; role: string }) {
  const db = getDb();
  const o = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
  if (!o) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
  const isParty = o.buyerId === user.id || o.sellerId === user.id || user.role === "admin";
  if (!isParty) throw new TRPCError({ code: "FORBIDDEN", message: "You are not part of this order." });
  return o;
}

const CHAT_STATUSES = ["payment_verified", "delivered", "disputed", "completed"];

export const orderRouter = createRouter({
  // Step 1 — Buy Now: create unique order and atomically lock the listing
  create: authedQuery
    .input(z.object({ listingId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      rateLimit(`order:${ctx.user.id}`, 10, 60_000);
      const db = getDb();
      const l = await db.query.listings.findFirst({ where: eq(listings.id, input.listingId) });
      if (!l || l.status !== "active") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This listing is no longer available." });
      }
      if (l.sellerId === ctx.user.id) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot buy your own listing." });
      }
      if (l.currency && l.currency !== "INR") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "International-currency checkout is not available yet. Please choose an INR listing.",
        });
      }
      // Atomic lock — only one buyer can flip active -> reserved
      const lock = await db
        .update(listings)
        .set({ status: "reserved" })
        .where(and(eq(listings.id, l.id), eq(listings.status, "active")));
      if ((lock[0] as { affectedRows?: number }).affectedRows === 0) {
        throw new TRPCError({ code: "CONFLICT", message: "Someone else just grabbed this listing." });
      }
      const feePercent = await getFeePercent();
      const pricePaise = toPaise(l.price);
      const { fee, seller } = splitFee(pricePaise, feePercent);
      const no = orderNo();
      const [{ id }] = await db
        .insert(orders)
        .values({
          orderNo: no,
          listingId: l.id,
          buyerId: ctx.user.id,
          sellerId: l.sellerId,
          price: toRupees(pricePaise),
          feePercent: feePercent.toFixed(2),
          platformFee: toRupees(fee),
          sellerAmount: toRupees(seller),
        })
        .$returningId();
      await notify(
        l.sellerId,
        "New order received",
        `${ctx.user.name ?? "A buyer"} wants to buy "${l.title}". Waiting for payment.`,
        `/orders/${id}`,
      );
      return { id, orderNo: no };
    }),

  // Step 2 — buyer submits payment proof / transaction reference
  submitPayment: authedQuery
    .input(
      z.object({
        orderId: z.number().int().positive(),
        paymentMethod: z.enum(["upi", "airtel", "crypto"]),
        transactionRef: z.string().trim().min(4, "Enter the transaction ID / hash").max(255),
        paymentProof: z.string().max(600).optional(), // storage key
        note: z.string().max(500).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (o.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (!["awaiting_payment", "payment_rejected"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Cannot submit payment while order is ${o.status}.` });
      }
      await db
        .update(orders)
        .set({
          paymentMethod: input.paymentMethod,
          transactionRef: input.transactionRef,
          paymentProof: input.paymentProof ?? null,
          paymentNote: input.note ?? null,
          paymentRejectReason: null,
          status: "payment_verification",
          paidAt: new Date(),
        })
        .where(eq(orders.id, o.id));
      await notify(o.sellerId, "Payment submitted", `Order ${o.orderNo} is pending verification.`, `/orders/${o.id}`);
      const admins = await db.query.users.findMany({ where: eq(users.role, "admin") });
      await Promise.all(
        admins.map((a) =>
          notify(a.id, "Payment needs verification", `Order ${o.orderNo} — ₹${o.price} via ${input.paymentMethod}.`, `/admin?tab=orders`),
        ),
      );
      return { ok: true };
    }),

  // Buyer cancels before payment is verified — listing is released
  cancel: authedQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (o.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (!["awaiting_payment", "payment_rejected", "payment_verification"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This order can no longer be cancelled." });
      }
      await db.update(orders).set({ status: "cancelled" }).where(eq(orders.id, o.id));
      await db.update(listings).set({ status: "active" }).where(eq(listings.id, o.listingId));
      await notify(o.sellerId, "Order cancelled", `Order ${o.orderNo} was cancelled by the buyer.`);
      return { ok: true };
    }),

  // Seller confirms they delivered the account
  markDelivered: authedQuery
    .input(z.object({ orderId: z.number().int().positive(), note: z.string().max(500).optional() }))
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (o.sellerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (o.status !== "payment_verified") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Payment must be verified before delivery." });
      }
      await db
        .update(orders)
        .set({ status: "delivered", deliveredAt: new Date() })
        .where(eq(orders.id, o.id));
      await db.insert(messages).values({
        orderId: o.id,
        senderId: null,
        body: `Seller marked the account as delivered.${input.note ? ` Note: ${input.note}` : ""}`,
        isSystem: true,
      });
      await notify(o.buyerId, "Order delivered", `Order ${o.orderNo} — check the deal room and confirm receipt.`, `/orders/${o.id}`);
      return { ok: true };
    }),

  // Buyer confirms receipt -> complete order, settle 5% fee, credit seller wallet
  confirmReceived: authedQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {

      const o = await getOrderForUser(input.orderId, ctx.user);
      if (o.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (!["payment_verified", "delivered"].includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Order is not ready to be confirmed." });
      }
      await settleOrder(o.id);
      return { ok: true };
    }),

  detail: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const o = await getOrderForUser(input.id, ctx.user);
      const l = await db.query.listings.findFirst({ where: eq(listings.id, o.listingId) });
      const buyer = await db.query.users.findFirst({ where: eq(users.id, o.buyerId) });
      const seller = await db.query.users.findFirst({ where: eq(users.id, o.sellerId) });
      const review = await db.query.reviews.findFirst({ where: eq(reviews.orderId, o.id) });
      const dispute = await db.query.disputes.findFirst({ where: eq(disputes.orderId, o.id) });
      return {
        order: o,
        listing: l
          ? {
              id: l.id,
              title: l.title,
              gameId: l.gameId,
              deliveryMethod: l.deliveryMethod,
              screenshots: JSON.parse(l.screenshots ?? "[]") as string[],
              status: l.status,
            }
          : null,
        buyer: buyer ? { id: buyer.id, name: buyer.name } : null,
        seller: seller ? { id: seller.id, name: seller.name } : null,
        review: review ?? null,
        dispute: dispute ?? null,
        myRole: o.buyerId === ctx.user.id ? "buyer" : o.sellerId === ctx.user.id ? "seller" : "admin",
      };
    }),

  myPurchases: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.query.orders.findMany({
      where: eq(orders.buyerId, ctx.user.id),
      orderBy: [desc(orders.createdAt)],
    });
    return Promise.all(
      rows.map(async (o) => {
        const l = await db.query.listings.findFirst({ where: eq(listings.id, o.listingId) });
        return { ...o, listingTitle: l?.title ?? "—" };
      }),
    );
  }),

  // ---- Private deal room (buyer + seller + admin only) ----
  messages: authedQuery
    .input(z.object({ orderId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      await getOrderForUser(input.orderId, ctx.user);
      const rows = await db.query.messages.findMany({
        where: eq(messages.orderId, input.orderId),
        orderBy: [messages.createdAt],
        limit: 500,
      });
      const senderIds = [...new Set(rows.map((m) => m.senderId).filter((x): x is number => x != null))];
      const senders = senderIds.length
        ? await Promise.all(
            senderIds.map((id) => db.query.users.findFirst({ where: eq(users.id, id) })),
          )
        : [];
      const map = new Map(senders.filter(Boolean).map((u) => [u!.id, u!]));
      return rows.map((m) => ({
        ...m,
        sender: m.senderId
          ? { id: m.senderId, name: map.get(m.senderId)?.name ?? "User", role: map.get(m.senderId)?.role ?? "user" }
          : null,
      }));
    }),

  sendMessage: authedQuery
    .input(
      z.object({
        orderId: z.number().int().positive(),
        body: z.string().trim().min(1).max(2000),
        attachment: z.string().max(600).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      rateLimit(`msg:${ctx.user.id}`, 30, 60_000);
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (!CHAT_STATUSES.includes(o.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "The deal room opens once payment is verified." });
      }
      await db.insert(messages).values({
        orderId: o.id,
        senderId: ctx.user.id,
        body: input.body,
        attachment: input.attachment ?? null,
      });
      const other = o.buyerId === ctx.user.id ? o.sellerId : o.buyerId;
      await notify(other, "New deal message", `Order ${o.orderNo}`, `/orders/${o.id}`);
      return { ok: true };
    }),

  // ---- Review after completion ----
  review: authedQuery
    .input(
      z.object({
        orderId: z.number().int().positive(),
        rating: z.number().int().min(1).max(5),
        comment: z.string().max(1000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (o.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (o.status !== "completed") throw new TRPCError({ code: "BAD_REQUEST", message: "You can review after the order completes." });
      const existing = await db.query.reviews.findFirst({ where: eq(reviews.orderId, o.id) });
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Order already reviewed." });
      await db.insert(reviews).values({
        orderId: o.id,
        reviewerId: ctx.user.id,
        sellerId: o.sellerId,
        rating: input.rating,
        comment: input.comment ?? null,
      });
      await notify(o.sellerId, "New review", `You received a ${input.rating}★ review on order ${o.orderNo}.`);
      return { ok: true };
    }),

  // ---- Disputes ----
  openDispute: authedQuery
    .input(
      z.object({
        orderId: z.number().int().positive(),
        reason: z.string().trim().min(10).max(2000),
        evidence: z.string().max(600).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertActive(ctx.user);
      const db = getDb();
      const o = await getOrderForUser(input.orderId, ctx.user);
      if (ctx.user.role !== "admin") {
        if (!["payment_verification", "payment_verified", "delivered"].includes(o.status)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "This order cannot be disputed." });
        }
      }
      const existing = await db.query.disputes.findFirst({ where: eq(disputes.orderId, o.id) });
      if (existing && existing.status !== "resolved") {
        throw new TRPCError({ code: "CONFLICT", message: "A dispute is already open for this order." });
      }
      await db.transaction(async (tx) => {
        await tx.insert(disputes).values({
          orderId: o.id,
          openedBy: ctx.user.id,
          reason: input.reason,
          openerEvidence: input.evidence ?? null,
        });
        await tx.update(orders).set({ status: "disputed" }).where(eq(orders.id, o.id));
        await tx.insert(messages).values({
          orderId: o.id,
          senderId: null,
          body: `Dispute opened: ${input.reason.slice(0, 200)}`,
          isSystem: true,
        });
      });
      const admins = await db.query.users.findMany({ where: eq(users.role, "admin") });
      await Promise.all(admins.map((a) => notify(a.id, "Dispute opened", `Order ${o.orderNo} needs review.`, "/admin?tab=disputes")));
      return { ok: true };
    }),

  respondDispute: authedQuery
    .input(
      z.object({
        disputeId: z.number().int().positive(),
        response: z.string().trim().min(5).max(2000),
        evidence: z.string().max(600).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const d = await db.query.disputes.findFirst({ where: eq(disputes.id, input.disputeId) });
      if (!d) throw new TRPCError({ code: "NOT_FOUND" });
      const o = await getOrderForUser(d.orderId, ctx.user);
      if (d.openedBy === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "You opened this dispute." });
      if (d.status === "resolved") throw new TRPCError({ code: "BAD_REQUEST", message: "Dispute already resolved." });
      await db
        .update(disputes)
        .set({ response: input.response, responseEvidence: input.evidence ?? null, status: "under_review" })
        .where(eq(disputes.id, d.id));
      const other = o.buyerId === ctx.user.id ? o.sellerId : o.buyerId;
      await notify(other, "Dispute response", `The other party responded on order ${o.orderNo}.`, `/orders/${o.id}`);
      return { ok: true };
    }),
});

// Shared settlement: complete order, 5% (configured) platform fee, credit seller
export async function settleOrder(orderId: number) {
  const db = getDb();
  const o = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
  if (!o) throw new TRPCError({ code: "NOT_FOUND" });
  if (o.status === "completed") return;
  await ensureWallet(o.sellerId);
  await db.transaction(async (tx) => {
    await tx
      .update(orders)
      .set({ status: "completed", completedAt: new Date() })
      .where(eq(orders.id, o.id));
    await tx.update(listings).set({ status: "sold" }).where(eq(listings.id, o.listingId));
    const w = await tx.query.wallets.findFirst({ where: eq(wallets.userId, o.sellerId) });
    const available = toPaise(w?.availableBalance ?? "0");
    const earnings = toPaise(w?.totalEarnings ?? "0");
    const credit = toPaise(o.sellerAmount);
    await tx
      .update(wallets)
      .set({
        availableBalance: toRupees(available + credit),
        totalEarnings: toRupees(earnings + credit),
      })
      .where(eq(wallets.userId, o.sellerId));
    await tx.insert(walletTransactions).values({
      userId: o.sellerId,
      orderId: o.id,
      type: "sale_credit",
      amount: toRupees(credit),
      balanceAfter: toRupees(available + credit),
      note: `Sale of order ${o.orderNo} (fee ${o.feePercent}% = ₹${o.platformFee})`,
    });
    await tx.insert(messages).values({
      orderId: o.id,
      senderId: null,
      body: `Order completed. Platform fee ₹${o.platformFee} (${o.feePercent}%). Seller received ₹${o.sellerAmount}.`,
      isSystem: true,
    });
  });
  await notify(o.sellerId, "Payment released", `₹${o.sellerAmount} from order ${o.orderNo} is now in your available balance.`, "/seller?tab=wallet");
  await notify(o.buyerId, "Order completed", `Thanks for confirming order ${o.orderNo}. Enjoy your account!`, `/orders/${o.id}`);
}
