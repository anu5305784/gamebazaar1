# GAMEBAZAAR

A mobile-first gaming marketplace built with React, TypeScript, Vite, Hono, tRPC, Drizzle ORM, and MySQL.

## Included features

- Buyer/seller email-and-password registration and login
- Optional Kimi OAuth (requires Kimi OAuth configuration)
- Marketplace listings, image uploads, game/category filters, and search
- Listing categories: Game Accounts, In-Game Currency, Items & Skins, Game Services, Gift Cards, and Boosting
- Seller-selectable listing currency: INR, USD, EUR, GBP, RUB, UAH
- Seller dashboard, orders, wallet ledger, withdrawal requests, reviews, and notifications
- Admin dashboard for listings, users, orders, payment verification, disputes, withdrawals, settings, and commission
- Private buyer/seller/admin deal-room messaging
- Default platform commission setting of 5% (administrator can change it)
- Server-side permission checks and encrypted stored delivery credentials

## Important currency/payment notes

The existing checkout, wallet ledger, payment-proof review, and seller settlement flow is INR-based. Non-INR listings can be created and displayed in their selected currency, but checkout is intentionally disabled for those listings until a real multi-currency payment provider and settlement flow are configured. Listing currency is not automatically converted using invented rates.

The current payment verification flow is admin-reviewed; it is not a licensed third-party escrow service. Do not advertise a regulated escrow guarantee unless a compliant provider and required legal setup are in place.

## Requirements

- Node.js 20 or newer
- A MySQL-compatible database
- Persistent environment variables configured by the hosting provider

## Local setup

1. Copy `.env.example` to `.env` and fill in the required values.
2. Install dependencies:

   ```sh
   npm install
   ```

3. Apply the database schema (back up any existing database first):

   ```sh
   npm run db:push
   ```

4. Create/update the administrator account by setting `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` of at least 12 characters in `.env`, then run:

   ```sh
   npm run db:seed
   ```

5. Start development mode:

   ```sh
   npm run dev
   ```

6. For production, run:

   ```sh
   npm run build
   npm start
   ```

## Required production environment variables

- `DATABASE_URL`: MySQL connection string
- `APP_SECRET`: a long, random secret used to sign session cookies; keep it stable between deployments

`APP_ID` is only needed for Kimi OAuth. If omitted, local email/password authentication uses the stable ID `gamebazaar-local`.

Kimi OAuth is optional. To enable the “Continue with Kimi” button, configure all four values:

- `APP_ID`
- `KIMI_AUTH_URL`
- `KIMI_OPEN_URL`
- `VITE_KIMI_AUTH_URL` and `VITE_APP_ID` as frontend build-time variables

If those frontend values are not configured, the Kimi login button is hidden and local email/password login remains available.

`ADMIN_EMAIL` and `ADMIN_PASSWORD` are used by `npm run db:seed` to create the admin account. The seed script no longer ships with a public default admin password. If an admin already exists, change its password through a secure administrative process rather than relying on the seed script to overwrite it.

## Deploying on Northflank, Render, or another Node host

1. Upload this ZIP to a Git repository or hosting platform.
2. Configure `DATABASE_URL` and `APP_SECRET` in the host's environment settings. Do not commit `.env` or secrets to Git.
3. Build command: `npm install && npm run db:push && npm run build` (only run schema pushes after backing up an existing database).
4. Start command: `npm start`.
5. Configure `ADMIN_EMAIL` and `ADMIN_PASSWORD`, then run `npm run db:seed` once against the configured database.
6. Ensure the host routes public traffic to the service's `PORT` environment variable.

The project lockfile now uses the official npm registry URLs rather than the unavailable `npm.mirrors.msh.team` mirror.

## Before accepting real money

Configure and test a legitimate payment provider, verified server-side webhooks, refund handling, fraud controls, and compliant payout arrangements. Never mark a payment as verified from a browser-only action. Review the game publishers' terms and applicable law before enabling account sales.
