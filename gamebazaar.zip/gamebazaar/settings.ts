import { eq } from "drizzle-orm";
import { getDb } from "../queries/connection";
import { settings } from "@db/schema";

export const SETTING_KEYS = {
  platformFeePercent: "platform_fee_percent",
  minWithdrawal: "min_withdrawal",
  payUpi: "pay_upi",
  payAirtel: "pay_airtel",
  payCrypto: "pay_crypto",
  listingAutoApprove: "listing_auto_approve",
  marketplaceNotice: "marketplace_notice",
  listingsEnabled: "listings_enabled",
  withdrawalsEnabled: "withdrawals_enabled",
} as const;

export type PaymentMethodConfig = {
  enabled: boolean;
  label: string;
  details: string;
  network?: string; // crypto network/token info
};

export const DEFAULTS: Record<string, string> = {
  [SETTING_KEYS.platformFeePercent]: "5",
  [SETTING_KEYS.minWithdrawal]: "100",
  [SETTING_KEYS.listingAutoApprove]: "true",
  [SETTING_KEYS.listingsEnabled]: "true",
  [SETTING_KEYS.withdrawalsEnabled]: "true",
  [SETTING_KEYS.marketplaceNotice]:
    "Payment evidence is reviewed by the GameBazaar admin team. Never share account credentials outside the private deal room.",
  [SETTING_KEYS.payUpi]: JSON.stringify({
    enabled: true,
    label: "UPI",
    details: "8761986175@omni",
  } satisfies PaymentMethodConfig),
  [SETTING_KEYS.payAirtel]: JSON.stringify({
    enabled: true,
    label: "Airtel Payment Bank",
    details: "2778161684289SN0724@mairtel",
  } satisfies PaymentMethodConfig),
  [SETTING_KEYS.payCrypto]: JSON.stringify({
    enabled: true,
    label: "Crypto (USDT)",
    details: "0x1c1021930A690FD8C83A452C6F39379A5c3EE74E",
    network: "ERC-20 / USDT — send only on the Ethereum network",
  } satisfies PaymentMethodConfig),
};

export async function getSetting(key: string): Promise<string> {
  const db = getDb();
  const row = await db.query.settings.findFirst({ where: eq(settings.key, key) });
  if (row?.value != null) return row.value;
  return DEFAULTS[key] ?? "";
}

export async function setSetting(key: string, value: string) {
  const db = getDb();
  await db
    .insert(settings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}

export async function getFeePercent(): Promise<number> {
  const raw = await getSetting(SETTING_KEYS.platformFeePercent);
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0 || n > 50) return 5;
  return n;
}

export async function getPaymentMethods(): Promise<
  Record<"upi" | "airtel" | "crypto", PaymentMethodConfig>
> {
  const [upi, airtel, crypto] = await Promise.all([
    getSetting(SETTING_KEYS.payUpi),
    getSetting(SETTING_KEYS.payAirtel),
    getSetting(SETTING_KEYS.payCrypto),
  ]);
  const parse = (s: string): PaymentMethodConfig => {
    try {
      return JSON.parse(s);
    } catch {
      return { enabled: false, label: "", details: "" };
    }
  };
  return { upi: parse(upi), airtel: parse(airtel), crypto: parse(crypto) };
}

// Money helpers — always compute in paise (integer) to avoid float drift
export function toPaise(amount: string | number): number {
  return Math.round(Number(amount) * 100);
}
export function toRupees(paise: number): string {
  return (paise / 100).toFixed(2);
}
export function splitFee(pricePaise: number, feePercent: number) {
  const fee = Math.round((pricePaise * feePercent) / 100);
  return { fee, seller: pricePaise - fee };
}
