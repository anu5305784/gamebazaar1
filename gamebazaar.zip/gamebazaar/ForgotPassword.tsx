import { Link, useNavigate } from "react-router";
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ForgotPassword() {
  const [step, setStep] = useState<1 | 2>(1);
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const navigate = useNavigate();

  const request = trpc.localAuth.requestPasswordReset.useMutation({
    onSuccess: (r) => {
      setDevCode(r.devCode);
      setStep(2);
    },
  });
  const reset = trpc.localAuth.resetPassword.useMutation({
    onSuccess: () => {
      setDone(true);
      setTimeout(() => navigate("/login"), 1800);
    },
  });

  return (
    <Layout>
      <div className="mx-auto flex max-w-md flex-col items-center px-4 py-16">
        <Card className="w-full border-border bg-card">
          <CardHeader>
            <CardTitle className="font-display text-2xl">Reset password</CardTitle>
          </CardHeader>
          <CardContent>
            {done ? (
              <p className="text-sm text-primary">Password updated! Redirecting to login…</p>
            ) : step === 1 ? (
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  request.mutate({ email });
                }}
              >
                <p className="text-sm text-muted-foreground">Enter your account email to get a 6-digit reset code.</p>
                <div className="space-y-1.5">
                  <Label>Email</Label>
                  <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                {request.error && <p className="text-sm text-destructive">{request.error.message}</p>}
                <Button className="w-full" disabled={request.isPending}>
                  {request.isPending ? "Sending…" : "Send reset code"}
                </Button>
              </form>
            ) : (
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  reset.mutate({ email, code, password });
                }}
              >
                {devCode ? (
                  <p className="rounded-lg border border-primary/30 bg-primary/10 p-3 text-sm">
                    This deployment has no email delivery — your reset code is shown here:
                    <span className="ml-2 font-display text-lg font-bold tracking-widest text-primary">{devCode}</span>
                    <span className="mt-1 block text-xs text-muted-foreground">Valid for 15 minutes, single use.</span>
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground">If this email is registered, a reset code has been issued.</p>
                )}
                <div className="space-y-1.5">
                  <Label>Reset code</Label>
                  <Input required maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} placeholder="6-digit code" className="font-display tracking-widest" />
                </div>
                <div className="space-y-1.5">
                  <Label>New password</Label>
                  <Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
                </div>
                {reset.error && <p className="text-sm text-destructive">{reset.error.message}</p>}
                <Button className="w-full" disabled={reset.isPending}>
                  {reset.isPending ? "Resetting…" : "Set new password"}
                </Button>
              </form>
            )}
            <p className="mt-4 text-center text-sm text-muted-foreground">
              <Link to="/login" className="text-primary hover:underline">Back to login</Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
