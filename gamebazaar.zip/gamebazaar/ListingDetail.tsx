import { Link, useNavigate, useParams } from "react-router";
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Layout } from "@/components/Layout";
import { StorageImage } from "@/components/StorageImage";
import { ListingCard } from "@/components/ListingCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, listingTypeLabel, LISTING_STATUS } from "@/lib/format";
import { Star, ShieldCheck, Zap, Handshake, ChevronLeft, ChevronRight, BadgeCheck } from "lucide-react";

export default function ListingDetail() {
  const { id } = useParams();
  const listingId = Number(id);
  const { data, isLoading, error } = trpc.market.detail.useQuery({ id: listingId }, { enabled: !!listingId });
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const [shot, setShot] = useState(0);

  const createOrder = trpc.order.create.useMutation({
    onSuccess: (o) => navigate(`/checkout/${o.id}`),
  });

  if (error) return <Layout><div className="p-16 text-center text-muted-foreground">Listing not found.</div></Layout>;

  const l = data?.listing;
  const shots = l?.screenshots ?? [];
  const isOwn = user?.id === l?.sellerId;

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 py-8">
        {isLoading || !l ? (
          <div className="grid gap-6 md:grid-cols-2"><Skeleton className="aspect-video rounded-xl" /><Skeleton className="h-96 rounded-xl" /></div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-5">
            {/* Gallery + details */}
            <div className="lg:col-span-3">
              <div className="relative aspect-video overflow-hidden rounded-xl border border-border bg-secondary">
                <StorageImage storageKey={shots[shot]} alt={l.title} className="h-full w-full" />
                {shots.length > 1 && (
                  <>
                    <Button variant="secondary" size="icon" className="absolute left-2 top-1/2 -translate-y-1/2" onClick={() => setShot((shot - 1 + shots.length) % shots.length)}><ChevronLeft /></Button>
                    <Button variant="secondary" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2" onClick={() => setShot((shot + 1) % shots.length)}><ChevronRight /></Button>
                  </>
                )}
              </div>
              {shots.length > 1 && (
                <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
                  {shots.map((s, i) => (
                    <button key={s} onClick={() => setShot(i)} className={`h-16 w-24 shrink-0 overflow-hidden rounded-lg border ${i === shot ? "border-primary" : "border-border"}`}>
                      <StorageImage storageKey={s} alt="" className="h-full w-full" />
                    </button>
                  ))}
                </div>
              )}

              <div className="mt-6 space-y-5">
                <div>
                  <h2 className="font-display text-lg font-semibold">Account details</h2>
                  <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3">
                    {[
                      ["Game", data?.game?.name],
                      ["Account level", l.accountLevel],
                      ["Trophies / Rank", l.trophiesRank],
                      ["Delivery", l.deliveryMethod === "automatic" ? "⚡ Automatic" : "Manual"],
                      ["Listed", new Date(l.createdAt).toLocaleDateString("en-IN")],
                      ["Views", String(l.views)],
                    ].filter(([, v]) => v).map(([k, v]) => (
                      <div key={k} className="rounded-lg border border-border bg-card p-3">
                        <p className="text-xs text-muted-foreground">{k}</p>
                        <p className="mt-0.5 text-sm font-medium">{v}</p>
                      </div>
                    ))}
                  </div>
                </div>
                {l.skinsItems && (
                  <div>
                    <h3 className="font-display font-semibold">Skins & items</h3>
                    <p className="mt-1.5 whitespace-pre-wrap text-sm text-muted-foreground">{l.skinsItems}</p>
                  </div>
                )}
                <div>
                  <h3 className="font-display font-semibold">Description</h3>
                  <p className="mt-1.5 whitespace-pre-wrap text-sm text-muted-foreground">{l.description}</p>
                </div>
                {l.otherInfo && (
                  <div>
                    <h3 className="font-display font-semibold">Other information</h3>
                    <p className="mt-1.5 whitespace-pre-wrap text-sm text-muted-foreground">{l.otherInfo}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Buy panel */}
            <div className="space-y-4 lg:col-span-2">
              <Card className="sticky top-24 border-border bg-card">
                <CardContent className="space-y-4 p-5">
                  <div>
                    <h1 className="font-display text-xl font-bold">{l.title}</h1>
                    <Badge variant="secondary" className="mt-2">{data?.game?.name}</Badge>
                    <Badge variant="outline" className="ml-2 mt-2">{listingTypeLabel(l.listingType)}</Badge>
                    <Badge className={`ml-2 ${l.deliveryMethod === "automatic" ? "bg-primary text-primary-foreground" : ""}`} variant={l.deliveryMethod === "automatic" ? "default" : "outline"}>
                      {l.deliveryMethod === "automatic" ? <><Zap className="mr-1 h-3 w-3" />Automatic delivery</> : <><Handshake className="mr-1 h-3 w-3" />Manual delivery</>}
                    </Badge>
                  </div>
                  <p className="font-display text-3xl font-bold text-primary">{formatCurrency(l.price, l.currency)}</p>

                  {/* Seller card */}
                  <div className="rounded-lg border border-border bg-secondary/50 p-3.5">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-medium">
                        {data?.seller?.name}
                        {data?.seller?.isVerified && <BadgeCheck className="h-4 w-4 text-primary" />}
                      </span>
                      <span className="flex items-center gap-1 text-sm">
                        <Star className="h-4 w-4 fill-primary text-primary" />
                        {data?.seller?.avgRating?.toFixed(1) ?? "New"} ({data?.seller?.totalReviews ?? 0})
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {data?.seller?.totalSales ?? 0} completed sales · member since {data?.seller?.memberSince ? new Date(data.seller.memberSince).toLocaleDateString("en-IN") : "—"}
                    </p>
                  </div>

                  {l.currency && l.currency !== "INR" && (
                    <p className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-300">
                      This listing is priced in {l.currency}. International-currency checkout is not available yet, so this listing cannot be purchased through the current payment flow.
                    </p>
                  )}
                  {l.status !== "active" ? (
                    <Button className="w-full" size="lg" disabled>{LISTING_STATUS[l.status]?.label ?? "Unavailable"}</Button>
                  ) : l.currency && l.currency !== "INR" ? (
                    <Button className="w-full" size="lg" disabled>International checkout coming soon</Button>
                  ) : isOwn ? (
                    <Button className="w-full" size="lg" variant="secondary" asChild><Link to="/seller?tab=listings">Manage your listing</Link></Button>
                  ) : (
                    <Button
                      className="w-full lime-glow font-display text-base font-bold"
                      size="lg"
                      disabled={createOrder.isPending}
                      onClick={() => (isAuthenticated ? createOrder.mutate({ listingId: l.id }) : navigate("/login"))}
                    >
                      {createOrder.isPending ? "Reserving…" : "Buy Now"}
                    </Button>
                  )}
                  {createOrder.error && <p className="text-sm text-destructive">{createOrder.error.message}</p>}
                  <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
                    <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    Payment status is reviewed by the GameBazaar admin team. Use the private deal room, check the account carefully, and confirm delivery only after you have received what was agreed.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Seller reviews */}
        {(data?.reviews.length ?? 0) > 0 && (
          <section className="mt-12">
            <h2 className="mb-4 font-display text-xl font-bold">Seller reviews</h2>
            <div className="grid gap-3 md:grid-cols-2">
              {data!.reviews.map((r) => (
                <div key={r.id} className="rounded-xl border border-border bg-card p-4">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < r.rating ? "fill-primary text-primary" : "text-muted"}`} />
                    ))}
                    <span className="ml-2 text-xs text-muted-foreground">{new Date(r.createdAt).toLocaleDateString("en-IN")}</span>
                  </div>
                  {r.comment && <p className="mt-2 text-sm text-muted-foreground">{r.comment}</p>}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Related */}
        {(data?.related.length ?? 0) > 0 && (
          <section className="mt-12">
            <h2 className="mb-4 font-display text-xl font-bold">Similar listings</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {data!.related.map((r) => <ListingCard key={r.id} l={r as never} />)}
            </div>
          </section>
        )}
      </div>
    </Layout>
  );
}
