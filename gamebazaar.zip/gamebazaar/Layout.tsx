import { Link, useNavigate } from "react-router";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search, Bell, Home, LayoutGrid, Store, User, Shield, LogOut,
  Wallet, Package, Gamepad2, Plus,
} from "lucide-react";

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary lime-glow">
        <Gamepad2 className="h-5 w-5 text-primary-foreground" strokeWidth={2.4} />
      </div>
      <span className="font-display text-xl font-bold tracking-tight">
        GAME<span className="text-primary">BAZAAR</span>
      </span>
    </Link>
  );
}

function NotificationBell() {
  const { data } = trpc.market.notifications.useQuery(undefined, { refetchInterval: 15000 });
  const markRead = trpc.market.markNotificationsRead.useMutation();
  const utils = trpc.useUtils();
  const unread = data?.filter((n) => !n.isRead).length ?? 0;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
              {unread}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="flex items-center justify-between">
          Notifications
          {unread > 0 && (
            <button
              className="text-xs text-primary hover:underline"
              onClick={() => markRead.mutate(undefined, { onSuccess: () => utils.market.notifications.invalidate() })}
            >
              Mark all read
            </button>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <div className="max-h-80 overflow-y-auto">
          {!data?.length && <p className="p-4 text-sm text-muted-foreground">No notifications yet.</p>}
          {data?.map((n) => (
            <DropdownMenuItem key={n.id} asChild className={!n.isRead ? "bg-accent/50" : ""}>
              <Link to={n.link ?? "#"} className="flex flex-col items-start gap-0.5 py-2">
                <span className="text-sm font-medium">{n.title}</span>
                {n.body && <span className="line-clamp-2 text-xs text-muted-foreground">{n.body}</span>}
              </Link>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  return (
    <header className="sticky top-0 z-50 border-b border-border glass">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
        <Logo />
        <form
          className="hidden flex-1 items-center md:flex"
          onSubmit={(e) => {
            e.preventDefault();
            navigate(q.trim() ? `/browse?q=${encodeURIComponent(q.trim())}` : "/browse");
          }}
        >
          <div className="relative mx-auto w-full max-w-xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search accounts, games, items…"
              className="h-10 rounded-full border-input bg-secondary/60 pl-10"
            />
          </div>
        </form>
        <div className="ml-auto flex items-center gap-1.5">
          {isAuthenticated ? (
            <>
              <NotificationBell />
              {user?.role === "admin" && (
                <Button variant="ghost" size="sm" asChild className="hidden text-primary md:flex">
                  <Link to="/admin"><Shield className="mr-1.5 h-4 w-4" />Admin</Link>
                </Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="rounded-full">
                    <User className="mr-1.5 h-4 w-4" />
                    <span className="max-w-24 truncate">{user?.name ?? "Account"}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52">
                  <DropdownMenuLabel>
                    {user?.name}
                    {user?.isVerified && <span className="ml-1 text-xs text-primary">✓ Verified</span>}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild><Link to="/profile"><User className="mr-2 h-4 w-4" />Profile</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/orders"><Package className="mr-2 h-4 w-4" />My Orders</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/seller"><Store className="mr-2 h-4 w-4" />Seller Dashboard</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/seller?tab=wallet"><Wallet className="mr-2 h-4 w-4" />Wallet</Link></DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => logout()} className="text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" asChild><Link to="/login">Log in</Link></Button>
              <Button size="sm" asChild className="lime-glow font-semibold"><Link to="/signup">Sign up</Link></Button>
            </>
          )}
        </div>
      </div>
      <form
        className="border-t border-border px-4 py-2 md:hidden"
        onSubmit={(e) => {
          e.preventDefault();
          navigate(q.trim() ? `/browse?q=${encodeURIComponent(q.trim())}` : "/browse");
        }}
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search accounts, games…" className="h-9 rounded-full bg-secondary/60 pl-9" />
        </div>
      </form>
    </header>
  );
}

export function MobileNav() {
  const { isAuthenticated } = useAuth();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex items-stretch justify-around border-t border-border glass pb-[env(safe-area-inset-bottom)] md:hidden">
      {[
        { to: "/", icon: Home, label: "Home" },
        { to: "/browse", icon: LayoutGrid, label: "Browse" },
        { to: isAuthenticated ? "/seller?tab=new" : "/login", icon: Plus, label: "Sell" },
        { to: isAuthenticated ? "/orders" : "/login", icon: Package, label: "Orders" },
        { to: isAuthenticated ? "/profile" : "/login", icon: User, label: "Account" },
      ].map((i) => (
        <Link key={i.label} to={i.to} className="flex flex-1 flex-col items-center gap-1 px-1 py-3 text-xs font-medium text-muted-foreground hover:text-primary">
          <i.icon className="h-[26px] w-[26px]" />
          {i.label}
        </Link>
      ))}
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border pb-20 pt-10 md:pb-10">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            A marketplace for game accounts, in-game items, and services, with admin-reviewed payments and private deal rooms.
          </p>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-display font-semibold">Marketplace</p>
          <div className="flex flex-col gap-2 text-muted-foreground">
            <Link to="/browse" className="hover:text-primary">Browse listings</Link>
            <Link to="/seller" className="hover:text-primary">Start selling</Link>
            <Link to="/orders" className="hover:text-primary">Track orders</Link>
          </div>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-display font-semibold">Admin-reviewed payments</p>
          <p className="text-muted-foreground">
            Payment evidence is reviewed by the admin team before a deal proceeds. Use the private deal room and confirm delivery only after checking the order. Platform fee: 5%.
          </p>
        </div>
      </div>
      <p className="mt-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} GameBazaar. Trade only accounts that are legally transferable under each game's terms.</p>
    </footer>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 pb-20 md:pb-0">{children}</main>
      <MobileNav />
      <Footer />
    </div>
  );
}
