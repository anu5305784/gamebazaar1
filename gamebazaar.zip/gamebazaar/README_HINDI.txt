GAMEBAZAAR FIXED ZIP — HINDI QUICK GUIDE

Is ZIP mein aapki existing Kimi website ka project hai; ye sirf HTML demo nahi hai.

Naye options/fixes:
- Seller listing banate waqt currency choose kar sakta hai: INR, USD, EUR, GBP, RUB, UAH.
- Buyer Browse page par game, category, currency aur delivery filter kar sakta hai.
- Listing categories: Game Accounts, In-Game Currency, Items & Skins, Game Services, Gift Cards, Boosting.
- Game list mein Minecraft bhi hai.
- Admin panel, seller dashboard, orders, wallet ledger, withdrawal requests, commission setting aur private deal room project mein maujood hain.
- npm install mein aane wale unavailable npm mirror URLs ko official npm registry URLs se replace kiya gaya hai.
- APP_ID na hone par local email/password login ke liye startup ab us variable par fail nahi hona chahiye.
- Public default admin password hata diya gaya. Admin credentials environment se set honge.

IMPORTANT: ZIP upload karne ke baad website apne-aap real payments accept nahi karegi. Server ke liye MySQL database aur APP_SECRET zaroor configure karna hoga.

Northflank/Render jaisi Node hosting par:
1. ZIP ko extract karke project GitHub ya hosting platform par upload karein.
2. Environment variables set karein:
   DATABASE_URL = MySQL database connection string
   APP_SECRET = ek strong random secret (example generate karne ke liye: openssl rand -hex 32)
   ADMIN_EMAIL = aapka admin email
   ADMIN_PASSWORD = unique password, kam se kam 12 characters
3. Build command: npm install && npm run db:push && npm run build
   Existing database ho to pehle backup lena zaroori hai.
4. Start command: npm start
5. Database par ek baar admin create/update karne ke liye run karein: npm run db:seed
6. Kimi login chahiye toh APP_ID, KIMI_AUTH_URL, KIMI_OPEN_URL, VITE_KIMI_AUTH_URL aur VITE_APP_ID bhi configure karein. Nahi toh email/password login use karein.

Currency note: Non-INR listings display ho sakti hain, lekin checkout abhi INR-only hai. USD/EUR etc. ki live payment conversion enabled nahi hai.
