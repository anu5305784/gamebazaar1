import { z } from "zod";
import { and, desc, eq, like, or, sql, ne, avg, count } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { games, listings, notifications, reviews, users } from "@db/schema";
import { getPaymentMethods, getSetting, SETTING_KEYS } from "./lib/settings";

function parseShots(raw: string | null): string[] {
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.filter((s) => typeof s === "string") : [];
  } catch {
    return [];
  }
}

// Public listing payload — never includes encrypted credentials
function publicListing(l: typeof listings.$inferSelect) {
  const { deliveryCredentialsEnc: _drop, ...rest } = l;
  return { ...rest, screenshots: parseShots(l.screenshots) };
}

async function sellerCard(db: ReturnType<typeof getDb>, sellerId: number) {
  const seller = await db.query.users.findFirst({ where: eq(users.id, sellerId) });
  const agg = await db
    .select({ avgRating: avg(reviews.rating), total: count() })
    .from(reviews)
    .where(eq(reviews.sellerId, sellerId));
  const sales = await db.query.listings.findMany({
    where: and(eq(listings.sellerId, sellerId), eq(listings.status, "sold")),
  });
  return {
    id: sellerId,
    name: seller?.name ?? "Seller",
    isVerified: seller?.isVerified ?? false,
    memberSince: seller?.createdAt ?? null,
    avgRating: agg[0]?.avgRating ? Number(agg[0].avgRating) : null,
    totalReviews: Number(agg[0]?.total ?? 0),
    totalSales: sales.length,
  };
}

export const marketplaceRouter = createRouter({
  games: publicQuery.query(async () => {
    const db = getDb();
    const list = await db.query.games.findMany({
      where: eq(games.status, "active"),
      orderBy: [games.sortOrder, games.name],
    });
    const counts = await db
      .select({ gameId: listings.gameId, n: count() })
      .from(listings)
      .where(eq(listings.status, "active"))
      .groupBy(listings.gameId);
    const map = new Map(counts.map((c) => [c.gameId, Number(c.n)]));
    return list.map((g) => ({ ...g, activeListings: map.get(g.id) ?? 0 }));
  }),

  search: publicQuery
    .input(
      z.object({
        q: z.string().trim().max(120).optional(),
        gameId: z.number().int().positive().optional(),
        listingType: z.enum(["game_account", "in_game_currency", "items_skins", "game_services", "gift_cards", "boosting"]).optional(),
        currency: z.enum(["INR", "USD", "EUR", "GBP", "RUB", "UAH"]).optional(),
        minPrice: z.number().min(0).optional(),
        maxPrice: z.number().min(0).optional(),
        deliveryMethod: z.enum(["manual", "automatic"]).optional(),
        sort: z.enum(["newest", "price_asc", "price_desc", "popular"]).default("newest"),
        limit: z.number().int().min(1).max(60).default(24),
        offset: z.number().int().min(0).default(0),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [eq(listings.status, "active")];
      if (input.gameId) conds.push(eq(listings.gameId, input.gameId));
      if (input.listingType) conds.push(eq(listings.listingType, input.listingType));
      if (input.currency) conds.push(eq(listings.currency, input.currency));
      if (input.deliveryMethod) conds.push(eq(listings.deliveryMethod, input.deliveryMethod));
      if (input.q) {
        const q = `%${input.q}%`;
        conds.push(or(like(listings.title, q), like(listings.description, q))!);
      }
      if (input.minPrice != null) conds.push(sql`${listings.price} >= ${input.minPrice}`);
      if (input.maxPrice != null) conds.push(sql`${listings.price} <= ${input.maxPrice}`);
      const orderBy =
        input.sort === "price_asc"
          ? [listings.price]
          : input.sort === "price_desc"
            ? [desc(listings.price)]
            : input.sort === "popular"
              ? [desc(listings.views)]
              : [desc(listings.createdAt)];
      const rows = await db.query.listings.findMany({
        where: and(...conds),
        orderBy,
        limit: input.limit,
        offset: input.offset,
      });
      const gameIds = [...new Set(rows.map((r) => r.gameId))];
      const gameRows = gameIds.length
        ? await db.query.games.findMany({ where: or(...gameIds.map((id) => eq(games.id, id))) })
        : [];
      const gameMap = new Map(gameRows.map((g) => [g.id, g]));
      const sellerIds = [...new Set(rows.map((r) => r.sellerId))];
      const sellers = await Promise.all(sellerIds.map((id) => sellerCard(db, id)));
      const sellerMap = new Map(sellers.map((s) => [s.id, s]));
      return rows.map((r) => ({
        ...publicListing(r),
        game: gameMap.get(r.gameId) ?? null,
        seller: sellerMap.get(r.sellerId) ?? null,
      }));
    }),

  home: publicQuery.query(async () => {
    const db = getDb();
    const [featured, latest, popularGames] = await Promise.all([
      db.query.listings.findMany({
        where: and(eq(listings.status, "active"), eq(listings.featured, true)),
        orderBy: [desc(listings.createdAt)],
        limit: 8,
      }),
      db.query.listings.findMany({
        where: eq(listings.status, "active"),
        orderBy: [desc(listings.createdAt)],
        limit: 12,
      }),
      db.query.games.findMany({
        where: eq(games.status, "active"),
        orderBy: [games.sortOrder],
        limit: 12,
      }),
    ]);
    const attach = async (rows: typeof listings.$inferSelect[]) => {
      const gameIds = [...new Set(rows.map((r) => r.gameId))];
      const gameRows = gameIds.length
        ? await db.query.games.findMany({ where: or(...gameIds.map((id) => eq(games.id, id))) })
        : [];
      const gameMap = new Map(gameRows.map((g) => [g.id, g]));
      const sellerIds = [...new Set(rows.map((r) => r.sellerId))];
      const sellers = await Promise.all(sellerIds.map((id) => sellerCard(db, id)));
      const sellerMap = new Map(sellers.map((s) => [s.id, s]));
      return rows.map((r) => ({
        ...publicListing(r),
        game: gameMap.get(r.gameId) ?? null,
        seller: sellerMap.get(r.sellerId) ?? null,
      }));
    };
    const notice = await getSetting(SETTING_KEYS.marketplaceNotice);
    const counts = await db
      .select({ gameId: listings.gameId, n: count() })
      .from(listings)
      .where(eq(listings.status, "active"))
      .groupBy(listings.gameId);
    const countMap = new Map(counts.map((c) => [c.gameId, Number(c.n)]));
    return {
      featured: await attach(featured),
      latest: await attach(latest),
      games: popularGames.map((g) => ({ ...g, activeListings: countMap.get(g.id) ?? 0 })),
      notice,
    };
  }),

  detail: publicQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = getDb();
      const l = await db.query.listings.findFirst({ where: eq(listings.id, input.id) });
      if (!l || ["removed", "rejected"].includes(l.status)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      }
      if (l.status === "active") {
        await db.update(listings).set({ views: sql`${listings.views} + 1` }).where(eq(listings.id, l.id));
      }
      const game = await db.query.games.findFirst({ where: eq(games.id, l.gameId) });
      const seller = await sellerCard(db, l.sellerId);
      const sellerReviews = await db.query.reviews.findMany({
        where: eq(reviews.sellerId, l.sellerId),
        orderBy: [desc(reviews.createdAt)],
        limit: 10,
      });
      const related = await db.query.listings.findMany({
        where: and(
          eq(listings.gameId, l.gameId),
          eq(listings.status, "active"),
          ne(listings.id, l.id),
        ),
        limit: 6,
      });
      return {
        listing: publicListing(l),
        game: game ?? null,
        seller,
        reviews: sellerReviews,
        related: related.map(publicListing),
      };
    }),

  paymentMethods: publicQuery.query(async () => {
    const methods = await getPaymentMethods();
    const fee = await getSetting(SETTING_KEYS.platformFeePercent);
    return { methods, feePercent: fee };
  }),

  // ---- Profile / notifications ----
  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(80).optional(),
        bio: z.string().max(1000).optional(),
        accountType: z.enum(["buyer", "seller", "both"]).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(users).set(input).where(eq(users.id, ctx.user.id));
      const u = await db.query.users.findFirst({ where: eq(users.id, ctx.user.id) });
      const { passwordHash: _drop, ...safe } = u!;
      return safe;
    }),

  notifications: authedQuery.query(async ({ ctx }) => {
    return getDb().query.notifications.findMany({
      where: eq(notifications.userId, ctx.user.id),
      orderBy: [desc(notifications.createdAt)],
      limit: 50,
    });
  }),

  markNotificationsRead: authedQuery.mutation(async ({ ctx }) => {
    await getDb()
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, ctx.user.id));
    return { ok: true };
  }),
});
