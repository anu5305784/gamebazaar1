import { useNavigate, useParams } from "react-router";
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useImageUpload } from "@/hooks/useImageUpload";
import { inr, ORDER_STATUS } from "@/lib/format";
import { Copy, Check, Upload, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

function CopyButton({ text }: { text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <Button
      variant="outline" size="sm"
      onClick={async () => {
        await navigator.clipboard.writeText(text);
        setOk(true);
        setTimeout(() => setOk(false), 1500);
      }}
    >
      {ok ? <Check className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5" />}
      <span className="ml-1.5">{ok ? "Copied" : "Copy"}</span>
    </Button>
  );
}

export default function Checkout() {
  const { id } = useParams();
  const orderId = Number(id);
  const { isAuthenticated, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const { data, isLoading } = trpc.order.detail.useQuery({ id: orderId }, { enabled: isAuthenticated, refetchInterval: 8000 });
  const { data: payData } = trpc.market.paymentMethods.useQuery();
  const navigate = useNavigate();
  const { uploadFile, uploading } = useImageUpload();

  const [method, setMethod] = useState<"upi" | "airtel" | "crypto" | null>(null);
  const [txnRef, setTxnRef] = useState("");
  const [proofKey, setProofKey] = useState<string | null>(null);
  const [note, setNote] = useState("");

  const submit = trpc.order.submitPayment.useMutation({
    onSuccess: () => navigate(`/orders/${orderId}`),
  });
  const cancel = trpc.order.cancel.useMutation({ onSuccess: () => navigate("/orders") });

  if (authLoading || isLoading) return <Layout><div className="mx-auto max-w-3xl p-8"><Skeleton className="h-96 rounded-xl" /></div></Layout>;
  const o = data?.order;
  if (!o) return <Layout><div className="p-16 text-center text-muted-foreground">Order not found.</div></Layout>;
  if (!["awaiting_payment", "payment_rejected"].includes(o.status)) {
    navigate(`/orders/${o.id}`, { replace: true });
    return null;
  }

  const methods = payData?.methods;
  const entries = methods
    ? ([["upi", methods.upi], ["airtel", methods.airtel], ["crypto", methods.crypto]] as const).filter(([, m]) => m.enabled)
    : [];

  return (
    <Layout>
      <div className="mx-auto max-w-3xl px-4 py-8">
        <h1 className="font-display text-2xl font-bold">Checkout</h1>
        <p className="mt-1 text-sm text-muted-foreground">Order {o.orderNo}</p>

        {o.status === "payment_rejected" && (
          <div className="mt-4 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm">
            <p className="font-semibold text-destructive">Payment was rejected</p>
            <p className="mt-1 text-muted-foreground">{o.paymentRejectReason}. Please correct and resubmit below.</p>
          </div>
        )}

        {/* Order summary */}
        <Card className="mt-6 border-border bg-card">
          <CardHeader><CardTitle className="text-base">Order summary</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Item</span><span className="font-medium">{data?.listing?.title}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Price</span><span>{inr(o.price)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Platform fee ({o.feePercent}%, paid from seller's share)</span><span>{inr(o.platformFee)}</span></div>
            <div className="flex justify-between border-t border-border pt-2 font-display text-lg font-bold">
              <span>You pay</span><span className="text-primary">{inr(o.price)}</span>
            </div>
          </CardContent>
        </Card>

        {/* Payment methods */}
        <Card className="mt-4 border-border bg-card">
          <CardHeader><CardTitle className="text-base">1. Choose a payment method</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {entries.map(([key, m]) => (
              <button
                key={key}
                onClick={() => setMethod(key)}
                className={cn(
                  "w-full rounded-lg border p-4 text-left transition-colors",
                  method === key ? "border-primary bg-primary/10" : "border-border hover:border-primary/40",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{m.label}</span>
                  {method === key && <Check className="h-4 w-4 text-primary" />}
                </div>
                {method === key && (
                  <div className="mt-3 space-y-2 rounded-md bg-background/60 p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <code className="break-all font-mono text-sm text-primary">{m.details}</code>
                      <CopyButton text={m.details} />
                    </div>
                    {m.network && <p className="text-xs text-muted-foreground">{m.network}</p>}
                  </div>
                )}
              </button>
            ))}
            {!entries.length && <p className="text-sm text-muted-foreground">No payment methods configured.</p>}
          </CardContent>
        </Card>

        {/* Proof */}
        <Card className="mt-4 border-border bg-card">
          <CardHeader><CardTitle className="text-base">2. Submit payment proof</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label>{method === "crypto" ? "Transaction hash" : "Transaction ID / UTR"}</Label>
              <Input value={txnRef} onChange={(e) => setTxnRef(e.target.value)} placeholder={method === "crypto" ? "0x…" : "e.g. 4231xxxxxxxx"} />
            </div>
            <div className="space-y-1.5">
              <Label>Payment screenshot (optional but speeds up verification)</Label>
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border p-4 text-sm text-muted-foreground hover:border-primary/40">
                <Upload className="h-4 w-4" />
                {uploading ? "Uploading…" : proofKey ? "Screenshot attached ✓" : "Upload screenshot"}
                <input
                  type="file" accept="image/*" className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (f) setProofKey(await uploadFile(f));
                  }}
                />
              </label>
            </div>
            <div className="space-y-1.5">
              <Label>Note for the admin (optional)</Label>
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Anything that helps verify your payment" rows={2} />
            </div>
            {submit.error && <p className="text-sm text-destructive">{submit.error.message}</p>}
            <Button
              className="w-full font-semibold" size="lg"
              disabled={!method || txnRef.trim().length < 4 || submit.isPending || uploading}
              onClick={() => submit.mutate({ orderId: o.id, paymentMethod: method!, transactionRef: txnRef.trim(), paymentProof: proofKey ?? undefined, note: note || undefined })}
            >
              {submit.isPending ? "Submitting…" : `I've paid ${inr(o.price)} — submit for verification`}
            </Button>
            <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
              Payment is verified manually by our admin team. Clicking the button never auto-approves — status changes only after admin review ({ORDER_STATUS.payment_verification.label}).
            </p>
            <Button variant="ghost" className="w-full text-muted-foreground" disabled={cancel.isPending} onClick={() => cancel.mutate({ orderId: o.id })}>
              Cancel order and release the listing
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
