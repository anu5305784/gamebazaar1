import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDate, inr, ORDER_STATUS } from "@/lib/format";
import { Package } from "lucide-react";

export default function Orders() {
  useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const { data, isLoading } = trpc.order.myPurchases.useQuery();

  return (
    <Layout>
      <div className="mx-auto max-w-4xl px-4 py-8">
        <h1 className="font-display text-2xl font-bold">My orders</h1>
        <div className="mt-6 space-y-3">
          {isLoading && Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
          {data?.map((o) => {
            const st = ORDER_STATUS[o.status] ?? { label: o.status, color: "" };
            return (
              <Card key={o.id} className="border-border bg-card">
                <CardContent className="flex flex-wrap items-center gap-4 p-4">
                  <div className="min-w-0 flex-1">
                    <Link to={`/orders/${o.id}`} className="line-clamp-1 font-medium hover:text-primary">{o.listingTitle}</Link>
                    <p className="mt-0.5 text-xs text-muted-foreground">{o.orderNo} · {fmtDate(o.createdAt)}</p>
                  </div>
                  <span className={`text-sm font-medium ${st.color}`}>{st.label}</span>
                  <span className="font-display font-bold text-primary">{inr(o.price)}</span>
                  <Button size="sm" variant="outline" asChild>
                    <Link to={o.status === "awaiting_payment" || o.status === "payment_rejected" ? `/checkout/${o.id}` : `/orders/${o.id}`}>
                      {o.status === "awaiting_payment" || o.status === "payment_rejected" ? "Pay now" : "Open"}
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
          {!isLoading && !data?.length && (
            <div className="rounded-xl border border-dashed border-border p-16 text-center">
              <Package className="mx-auto h-10 w-10 text-muted-foreground" />
              <p className="mt-3 text-muted-foreground">No orders yet.</p>
              <Button className="mt-4" asChild><Link to="/browse">Browse listings</Link></Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
