import { Link, useSearchParams } from "react-router";
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { fmtDate, inr, LISTING_STATUS, ORDER_STATUS } from "@/lib/format";
import {
  ShieldCheck, Eye, LayoutDashboard, Users, Store, Package, CreditCard,
  Wallet, AlertTriangle, Gamepad2, Settings as SettingsIcon, ScrollText,
  Pencil, Trash2, UserCog,
} from "lucide-react";
import { StorageImage } from "@/components/StorageImage";

const NAV = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "users", label: "Users", icon: Users },
  { key: "listings", label: "Listings", icon: Store },
  { key: "orders", label: "Orders / Deals", icon: Package },
  { key: "payments", label: "Payments", icon: CreditCard },
  { key: "withdrawals", label: "Withdrawals", icon: Wallet },
  { key: "disputes", label: "Disputes", icon: AlertTriangle },
  { key: "games", label: "Games", icon: Gamepad2 },
  { key: "settings", label: "Settings", icon: SettingsIcon },
  { key: "audit", label: "Activity Log", icon: ScrollText },
] as const;

function Stat({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <Card className="border-border bg-card"><CardContent className="p-5">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`mt-1 font-display text-2xl font-bold ${accent ? "text-primary" : ""}`}>{value}</p>
    </CardContent></Card>
  );
}

type SettingsShape = {
  platformFeePercent: string;
  minWithdrawal: string;
  listingAutoApprove: "true" | "false";
  listingsEnabled: "true" | "false";
  withdrawalsEnabled: "true" | "false";
  marketplaceNotice: string;
  paymentMethods: {
    upi: { enabled: boolean; label: string; details: string };
    airtel: { enabled: boolean; label: string; details: string };
    crypto: { enabled: boolean; label: string; details: string; network?: string };
  };
};

function UserDetailDialog({ userId, onClose }: { userId: number; onClose: () => void }) {
  const { data, isLoading } = trpc.admin.userDetail.useQuery({ userId });
  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader><DialogTitle>User profile</DialogTitle></DialogHeader>
        {isLoading || !data ? (
          <Skeleton className="h-64 rounded-xl" />
        ) : (
          <div className="space-y-5 text-sm">
            <div className="rounded-lg border border-border p-4">
              <p className="font-display text-base font-semibold">
                {data.user.name}
                {data.user.role === "admin" && <Badge className="ml-2 bg-primary text-primary-foreground">admin</Badge>}
                {data.user.isVerified && <Badge variant="secondary" className="ml-2">✓ verified</Badge>}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {data.user.email ?? data.user.unionId} · {data.user.accountType} · {data.user.status} · joined {fmtDate(data.user.createdAt)}
              </p>
              {data.wallet && (
                <p className="mt-2 text-xs text-muted-foreground">
                  Wallet: available <span className="text-primary">{inr(data.wallet.availableBalance)}</span> · pending {inr(data.wallet.pendingBalance)} · lifetime earned {inr(data.wallet.totalEarnings)}
                </p>
              )}
            </div>
            <div>
              <p className="mb-2 font-display font-semibold">Orders ({data.orders.length})</p>
              <div className="space-y-1.5">
                {data.orders.map((o) => (
                  <div key={o.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-border p-2.5 text-xs">
                    <Link to={`/orders/${o.id}`} className="font-medium text-primary hover:underline">{o.orderNo}</Link>
                    <span>{o.buyerId === userId ? "as buyer" : "as seller"}</span>
                    <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                    <span className="ml-auto">{inr(o.price)}</span>
                    <span className="text-muted-foreground">{fmtDate(o.createdAt)}</span>
                  </div>
                ))}
                {!data.orders.length && <p className="text-xs text-muted-foreground">No orders.</p>}
              </div>
            </div>
            <div>
              <p className="mb-2 font-display font-semibold">Listings ({data.listings.length})</p>
              <div className="space-y-1.5">
                {data.listings.map((l) => (
                  <div key={l.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-border p-2.5 text-xs">
                    <Link to={`/listing/${l.id}`} className="line-clamp-1 font-medium hover:text-primary">{l.title}</Link>
                    <Badge variant="outline" className={LISTING_STATUS[l.status]?.color}>{LISTING_STATUS[l.status]?.label}</Badge>
                    <span className="ml-auto">{inr(l.price)}</span>
                  </div>
                ))}
                {!data.listings.length && <p className="text-xs text-muted-foreground">No listings.</p>}
              </div>
            </div>
            <div>
              <p className="mb-2 font-display font-semibold">Payment / wallet history ({data.transactions.length})</p>
              <div className="space-y-1.5">
                {data.transactions.map((t) => (
                  <div key={t.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-border p-2.5 text-xs">
                    <span className="font-mono">{t.type}</span>
                    <span className={Number(t.amount) >= 0 ? "text-primary" : "text-destructive"}>{inr(t.amount)}</span>
                    {t.note && <span className="text-muted-foreground">{t.note}</span>}
                    <span className="ml-auto text-muted-foreground">{fmtDate(t.createdAt)}</span>
                  </div>
                ))}
                {!data.transactions.length && <p className="text-xs text-muted-foreground">No transactions.</p>}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

type AdminListing = {
  id: number;
  title: string;
  price: string;
  description: string | null;
  accountLevel: string | null;
  trophiesRank: string | null;
  skinsItems: string | null;
  otherInfo: string | null;
};

function EditListingDialog({ listing, onClose }: { listing: AdminListing; onClose: () => void }) {
  const utils = trpc.useUtils();
  const [f, setF] = useState({
    title: listing.title,
    price: String(Number(listing.price)),
    description: listing.description ?? "",
    accountLevel: listing.accountLevel ?? "",
    trophiesRank: listing.trophiesRank ?? "",
    skinsItems: listing.skinsItems ?? "",
    otherInfo: listing.otherInfo ?? "",
  });
  const update = trpc.admin.updateListing.useMutation({
    onSuccess: () => { utils.admin.allListings.invalidate(); onClose(); },
  });
  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-h-[85vh] max-w-xl overflow-y-auto">
        <DialogHeader><DialogTitle>Edit listing #{listing.id}</DialogTitle></DialogHeader>
        <div className="space-y-3 text-sm">
          <div className="space-y-1.5"><Label>Title</Label><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Price (₹)</Label><Input type="number" min="1" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Account level</Label><Input value={f.accountLevel} onChange={(e) => setF({ ...f, accountLevel: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label>Trophies / rank</Label><Input value={f.trophiesRank} onChange={(e) => setF({ ...f, trophiesRank: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Description</Label><Textarea rows={4} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Skins / items</Label><Textarea rows={2} value={f.skinsItems} onChange={(e) => setF({ ...f, skinsItems: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Other info</Label><Textarea rows={2} value={f.otherInfo} onChange={(e) => setF({ ...f, otherInfo: e.target.value })} /></div>
          {update.error && <p className="text-destructive">{update.error.message}</p>}
          <Button
            className="w-full"
            disabled={update.isPending || f.title.trim().length < 5 || f.description.trim().length < 10 || !(Number(f.price) > 0)}
            onClick={() => update.mutate({
              id: listing.id,
              title: f.title.trim(),
              price: Number(f.price),
              description: f.description.trim(),
              accountLevel: f.accountLevel.trim() || undefined,
              trophiesRank: f.trophiesRank.trim() || undefined,
              skinsItems: f.skinsItems.trim() || undefined,
              otherInfo: f.otherInfo.trim() || undefined,
            })}
          >
            {update.isPending ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Admin() {
  const { user, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true, redirectPath: LOGIN_PATH });
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "dashboard";
  const utils = trpc.useUtils();

  const isAdmin = user?.role === "admin";
  const { data: stats } = trpc.admin.stats.useQuery(undefined, { enabled: isAdmin, refetchInterval: 15000 });
  const { data: usersList } = trpc.admin.users.useQuery({}, { enabled: isAdmin && tab === "users" });
  const { data: listingsList } = trpc.admin.allListings.useQuery({}, { enabled: isAdmin && tab === "listings" });
  const { data: ordersList } = trpc.admin.allOrders.useQuery({}, { enabled: isAdmin && (tab === "orders" || tab === "payments"), refetchInterval: 10000 });
  const { data: wds } = trpc.admin.allWithdrawals.useQuery(undefined, { enabled: isAdmin && tab === "withdrawals" });
  const { data: balances } = trpc.admin.sellerBalances.useQuery(undefined, { enabled: isAdmin && tab === "withdrawals" });
  const { data: disputesList } = trpc.admin.allDisputes.useQuery(undefined, { enabled: isAdmin && tab === "disputes" });
  const { data: allGames } = trpc.admin.allGames.useQuery(undefined, { enabled: isAdmin && tab === "games" });
  const { data: settingsData } = trpc.admin.getSettings.useQuery(undefined, { enabled: isAdmin && tab === "settings" });
  const { data: logs } = trpc.admin.auditLogs.useQuery(undefined, { enabled: isAdmin && tab === "audit" });
  const { data: credLogs } = trpc.admin.credentialAccessLogs.useQuery(undefined, { enabled: isAdmin && tab === "audit" });

  const [userQ, setUserQ] = useState("");
  const [orderFilter, setOrderFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [listingFilter, setListingFilter] = useState("all");
  const [rejectReason, setRejectReason] = useState("");
  const [gameName, setGameName] = useState("");
  const [settingsForm, setSettingsForm] = useState<string | null>(null);
  const [viewUserId, setViewUserId] = useState<number | null>(null);
  const [editListing, setEditListing] = useState<AdminListing | null>(null);
  const [wdNote, setWdNote] = useState<{ id: number; approve: boolean } | null>(null);
  const [wdNoteText, setWdNoteText] = useState("");

  const setUserStatus = trpc.admin.setUserStatus.useMutation({ onSuccess: () => utils.admin.users.invalidate() });
  const setUserVerified = trpc.admin.setUserVerified.useMutation({ onSuccess: () => utils.admin.users.invalidate() });
  const setUserRole = trpc.admin.setUserRole.useMutation({ onSuccess: () => utils.admin.users.invalidate() });
  const deleteUser = trpc.admin.deleteUser.useMutation({ onSuccess: () => utils.admin.users.invalidate() });
  const setListingStatus = trpc.admin.setListingStatus.useMutation({ onSuccess: () => utils.admin.allListings.invalidate() });
  const setFeatured = trpc.admin.setListingFeatured.useMutation({ onSuccess: () => utils.admin.allListings.invalidate() });
  const verifyPayment = trpc.admin.verifyPayment.useMutation({ onSuccess: () => utils.admin.allOrders.invalidate() });
  const rejectPayment = trpc.admin.rejectPayment.useMutation({ onSuccess: () => { utils.admin.allOrders.invalidate(); setRejectReason(""); } });
  const completeOrder = trpc.admin.completeOrder.useMutation({ onSuccess: () => utils.admin.allOrders.invalidate() });
  const cancelOrder = trpc.admin.cancelOrder.useMutation({ onSuccess: () => utils.admin.allOrders.invalidate() });
  const refundOrder = trpc.admin.refundOrder.useMutation({ onSuccess: () => utils.admin.allOrders.invalidate() });
  const setOrderStatus = trpc.admin.setOrderStatus.useMutation({ onSuccess: () => utils.admin.allOrders.invalidate() });
  const processWd = trpc.admin.processWithdrawal.useMutation({
    onSuccess: () => { utils.admin.allWithdrawals.invalidate(); utils.admin.sellerBalances.invalidate(); setWdNote(null); setWdNoteText(""); },
  });
  const resolveDispute = trpc.admin.resolveDispute.useMutation({ onSuccess: () => utils.admin.allDisputes.invalidate() });
  const saveGame = trpc.admin.saveGame.useMutation({ onSuccess: () => { utils.admin.allGames.invalidate(); utils.market.games.invalidate(); setGameName(""); } });
  const deleteGame = trpc.admin.deleteGame.useMutation({ onSuccess: () => { utils.admin.allGames.invalidate(); utils.market.games.invalidate(); } });
  const saveSettings = trpc.admin.saveSettings.useMutation({ onSuccess: () => { utils.admin.getSettings.invalidate(); setSettingsForm(null); } });

  if (authLoading) return <Layout><div className="p-16"><Skeleton className="h-96 rounded-xl" /></div></Layout>;
  if (!isAdmin) {
    return (
      <Layout>
        <div className="mx-auto max-w-md px-4 py-24 text-center">
          <ShieldCheck className="mx-auto h-12 w-12 text-muted-foreground" />
          <h1 className="mt-4 font-display text-xl font-bold">Admin access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">This area is restricted to marketplace administrators.</p>
        </div>
      </Layout>
    );
  }

  const filteredOrders = ordersList?.filter((o) => orderFilter === "all" || o.status === orderFilter);
  const filteredListings = listingsList?.filter((l) => listingFilter === "all" || l.status === listingFilter);
  const filteredUsers = usersList?.filter((u) => !userQ || u.name?.toLowerCase().includes(userQ.toLowerCase()) || u.email?.toLowerCase().includes(userQ.toLowerCase()));
  const paymentRows = ordersList?.filter((o) => {
    if (paymentFilter === "all") return true;
    if (paymentFilter === "pending") return ["awaiting_payment", "payment_verification", "payment_rejected"].includes(o.status);
    if (paymentFilter === "completed") return ["payment_verified", "delivered", "completed"].includes(o.status);
    if (paymentFilter === "failed") return ["cancelled", "refunded"].includes(o.status);
    return true;
  });

  // settings local form state (initialized once from server)
  if (settingsData && settingsForm === null) setSettingsForm(JSON.stringify(settingsData));
  const sf = (settingsForm ? JSON.parse(settingsForm) : settingsData) as SettingsShape | undefined;

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="flex items-center gap-2 font-display text-2xl font-bold"><ShieldCheck className="h-6 w-6 text-primary" /> Admin panel</h1>
        <div className="mt-6 md:grid md:grid-cols-[210px_1fr] md:gap-8">
          {/* Sidebar (desktop) / scroll chips (mobile) */}
          <nav className="scrollbar-thin -mx-4 mb-6 flex gap-1.5 overflow-x-auto px-4 pb-1 md:mx-0 md:mb-0 md:flex-col md:gap-1 md:overflow-visible md:px-0">
            {NAV.map((n) => (
              <button
                key={n.key}
                onClick={() => setParams({ tab: n.key })}
                className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors ${
                  tab === n.key
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <n.icon className="h-4.5 w-4.5" />
                {n.label}
              </button>
            ))}
          </nav>

          <div className="min-w-0">
          {tab === "dashboard" && (
            <div>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
                <Stat label="Total users" value={stats?.totalUsers ?? "…"} />
                <Stat label="Buyers" value={stats?.buyers ?? "…"} />
                <Stat label="Sellers" value={stats?.sellers ?? "…"} />
                <Stat label="Active listings" value={stats?.activeListings ?? "…"} />
                <Stat label="Sold listings" value={stats?.soldListings ?? "…"} />
                <Stat label="Total orders" value={stats?.totalOrders ?? "…"} />
                <Stat label="Pending payments" value={stats?.pendingPayments ?? "…"} />
                <Stat label="Pending deals" value={stats?.pendingDeals ?? "…"} />
                <Stat label="Completed orders" value={stats?.completedOrders ?? "…"} />
                <Stat label="Open disputes" value={stats?.openDisputes ?? "…"} />
                <Stat label="Total payments" value={inr(stats?.totalPayments)} />
                <Stat label="Platform fees earned" value={inr(stats?.platformRevenue)} accent />
                <Stat label="Pending withdrawals" value={stats?.pendingWithdrawals ?? "…"} />
              </div>
              <h2 className="mt-8 font-display text-lg font-semibold">Recent orders</h2>
              <div className="mt-3 space-y-2">
                {stats?.recentOrders.map((o) => (
                  <div key={o.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card p-3 text-sm">
                    <Link to={`/orders/${o.id}`} className="font-medium text-primary hover:underline">{o.orderNo}</Link>
                    <span className="text-muted-foreground">{inr(o.price)}</span>
                    <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                    <span className="ml-auto text-xs text-muted-foreground">{fmtDate(o.createdAt)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "users" && (
            <div>
              <Input placeholder="Search name or email…" value={userQ} onChange={(e) => setUserQ(e.target.value)} className="max-w-sm" />
              <div className="mt-4 space-y-2">
                {filteredUsers?.map((u) => (
                  <Card key={u.id} className="border-border bg-card"><CardContent className="flex flex-wrap items-center gap-3 p-4 text-sm">
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{u.name} {u.role === "admin" && <Badge className="ml-1 bg-primary text-primary-foreground">admin</Badge>} {u.isVerified && <Badge variant="secondary" className="ml-1">✓ verified</Badge>}</p>
                      <p className="text-xs text-muted-foreground">{u.email ?? u.unionId} · {u.accountType} · joined {fmtDate(u.createdAt)}</p>
                    </div>
                    <Badge variant="outline" className={u.status === "active" ? "text-primary" : u.status === "suspended" ? "text-amber-400" : "text-destructive"}>{u.status}</Badge>
                    <div className="flex flex-wrap gap-1.5">
                      <Button size="sm" variant="secondary" onClick={() => setViewUserId(u.id)}><Eye className="mr-1 h-3.5 w-3.5" />View</Button>
                      {u.role !== "admin" && (
                        <>
                          <Button size="sm" variant="outline" onClick={() => setUserVerified.mutate({ userId: u.id, verified: !u.isVerified })}>
                            {u.isVerified ? "Unverify" : "Verify"}
                          </Button>
                          {u.status !== "active" && <Button size="sm" variant="outline" onClick={() => setUserStatus.mutate({ userId: u.id, status: "active" })}>Reactivate</Button>}
                          {u.status !== "suspended" && <Button size="sm" variant="outline" onClick={() => setUserStatus.mutate({ userId: u.id, status: "suspended" })}>Suspend</Button>}
                          {u.status !== "banned" && <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm(`Ban ${u.name}?`)) setUserStatus.mutate({ userId: u.id, status: "banned" }); }}>Ban</Button>}
                        </>
                      )}
                      {u.id !== user?.id && (
                        <Button size="sm" variant="ghost" title="Change role" onClick={() => { if (confirm(`${u.role === "admin" ? "Revoke admin from" : "Make admin:"} ${u.name}?`)) setUserRole.mutate({ userId: u.id, role: u.role === "admin" ? "user" : "admin" }); }}>
                          <UserCog className="h-3.5 w-3.5" />
                        </Button>
                      )}
                      {u.role !== "admin" && u.id !== user?.id && (
                        <Button size="sm" variant="ghost" className="text-destructive" title="Delete user" onClick={() => { if (confirm(`Permanently delete ${u.name}? Their listings will be removed. This cannot be undone.`)) deleteUser.mutate({ userId: u.id }); }}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </CardContent></Card>
                ))}
              </div>
              {viewUserId != null && <UserDetailDialog userId={viewUserId} onClose={() => setViewUserId(null)} />}
            </div>
          )}

          {tab === "listings" && (
            <div>
              <Select value={listingFilter} onValueChange={setListingFilter}>
                <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  {Object.entries(LISTING_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="mt-4 space-y-2">
                {filteredListings?.map((l) => (
                  <Card key={l.id} className="border-border bg-card"><CardContent className="flex flex-wrap items-center gap-3 p-4 text-sm">
                    <div className="min-w-0 flex-1">
                      <Link to={`/listing/${l.id}`} className="line-clamp-1 font-medium hover:text-primary">{l.title}</Link>
                      <p className="text-xs text-muted-foreground">{l.game} · {l.sellerName} · {inr(l.price)} · {l.deliveryMethod}{l.hasCredentials ? " (creds stored)" : ""}</p>
                    </div>
                    <Badge variant="outline" className={LISTING_STATUS[l.status]?.color}>{LISTING_STATUS[l.status]?.label}</Badge>
                    {l.featured && <Badge className="bg-primary text-primary-foreground">featured</Badge>}
                    <div className="flex flex-wrap gap-1.5">
                      {l.status === "pending" && <Button size="sm" onClick={() => setListingStatus.mutate({ id: l.id, status: "active" })}>Approve</Button>}
                      {l.status === "pending" && <Button size="sm" variant="outline" onClick={() => setListingStatus.mutate({ id: l.id, status: "rejected" })}>Reject</Button>}
                      <Button size="sm" variant="outline" onClick={() => setEditListing(l)}><Pencil className="mr-1 h-3.5 w-3.5" />Edit</Button>
                      <Button size="sm" variant="outline" onClick={() => setFeatured.mutate({ id: l.id, featured: !l.featured })}>{l.featured ? "Unfeature" : "Feature"}</Button>
                      {l.status === "active" && <Button size="sm" variant="outline" onClick={() => { if (confirm("Mark this listing as sold?")) setListingStatus.mutate({ id: l.id, status: "sold" }); }}>Mark sold</Button>}
                      {l.status === "sold" && <Button size="sm" variant="outline" onClick={() => { if (confirm("Make this listing available again?")) setListingStatus.mutate({ id: l.id, status: "active" }); }}>Mark available</Button>}
                      {l.status !== "removed" && <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm("Hide/remove this listing?")) setListingStatus.mutate({ id: l.id, status: "removed" }); }}>Remove</Button>}
                      {l.status === "removed" && <Button size="sm" variant="outline" onClick={() => setListingStatus.mutate({ id: l.id, status: "active" })}>Unhide</Button>}
                    </div>
                  </CardContent></Card>
                ))}
              </div>
              {editListing && <EditListingDialog listing={editListing} onClose={() => setEditListing(null)} />}
            </div>
          )}

          {tab === "orders" && (
            <div>
              <Select value={orderFilter} onValueChange={setOrderFilter}>
                <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  {Object.entries(ORDER_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="mt-4 space-y-2">
                {filteredOrders?.map((o) => (
                  <Card key={o.id} className="border-border bg-card"><CardContent className="space-y-3 p-4 text-sm">
                    <div className="flex flex-wrap items-center gap-3">
                      <Link to={`/orders/${o.id}`} className="font-medium text-primary hover:underline">{o.orderNo}</Link>
                      <span className="line-clamp-1 text-muted-foreground">{o.listingTitle}</span>
                      <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                      <span className="ml-auto font-display font-bold text-primary">{inr(o.price)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Buyer: {o.buyerName} · Seller: {o.sellerName} · Fee {o.feePercent}% = {inr(o.platformFee)} · Seller gets {inr(o.sellerAmount)}
                      {o.paymentMethod && <> · {o.paymentMethod.toUpperCase()} · ref: <code className="font-mono">{o.transactionRef}</code></>}
                    </p>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {o.paymentProof && (
                        <Dialog>
                          <DialogTrigger asChild><Button size="sm" variant="outline"><Eye className="mr-1 h-3.5 w-3.5" />Proof</Button></DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader><DialogTitle>Payment proof — {o.orderNo}</DialogTitle></DialogHeader>
                            <StorageImage storageKey={o.paymentProof} alt="Payment proof" className="max-h-[70vh] w-full rounded-lg object-contain" />
                            {o.paymentNote && <p className="text-sm text-muted-foreground">Buyer note: {o.paymentNote}</p>}
                          </DialogContent>
                        </Dialog>
                      )}
                      {o.status === "payment_verification" && (
                        <>
                          <Button size="sm" onClick={() => verifyPayment.mutate({ orderId: o.id })}>Verify payment</Button>
                          <Dialog>
                            <DialogTrigger asChild><Button size="sm" variant="outline" className="text-destructive">Reject</Button></DialogTrigger>
                            <DialogContent>
                              <DialogHeader><DialogTitle>Reject payment — {o.orderNo}</DialogTitle></DialogHeader>
                              <Textarea placeholder="Reason (shown to buyer)…" value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} />
                              <Button variant="destructive" disabled={rejectReason.trim().length < 3} onClick={() => rejectPayment.mutate({ orderId: o.id, reason: rejectReason })}>Reject payment</Button>
                            </DialogContent>
                          </Dialog>
                        </>
                      )}
                      {["payment_verified", "delivered", "disputed"].includes(o.status) && (
                        <>
                          <Button size="sm" variant="outline" onClick={() => { if (confirm("Force-complete this order? Seller gets credited.")) completeOrder.mutate({ orderId: o.id }); }}>Complete</Button>
                          <Button size="sm" variant="outline" onClick={() => { if (confirm("Refund this order? Listing returns to active.")) refundOrder.mutate({ orderId: o.id }); }}>Refund</Button>
                        </>
                      )}
                      {!["completed", "cancelled", "refunded"].includes(o.status) && (
                        <>
                          <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm("Cancel this order?")) cancelOrder.mutate({ orderId: o.id }); }}>Cancel</Button>
                          <Select
                            value=""
                            onValueChange={(v) => {
                              const note = prompt(`Change ${o.orderNo} to "${ORDER_STATUS[v]?.label}"? Optional admin note:`) ?? "";
                              if (confirm(`Confirm status change to ${ORDER_STATUS[v]?.label}?`)) {
                                setOrderStatus.mutate({ orderId: o.id, status: v as never, note: note || undefined });
                              }
                            }}
                          >
                            <SelectTrigger className="h-8 w-36 text-xs"><SelectValue placeholder="Set status…" /></SelectTrigger>
                            <SelectContent>
                              {Object.entries(ORDER_STATUS).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </>
                      )}
                      <Button size="sm" variant="secondary" asChild><Link to={`/orders/${o.id}`}>Deal room</Link></Button>
                    </div>
                    {setOrderStatus.error && <p className="text-xs text-destructive">{setOrderStatus.error.message}</p>}
                  </CardContent></Card>
                ))}
                {!filteredOrders?.length && <p className="text-sm text-muted-foreground">No orders in this view.</p>}
              </div>
            </div>
          )}

          {tab === "payments" && (
            <div>
              <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All payments</SelectItem>
                  <SelectItem value="pending">Pending / in verification</SelectItem>
                  <SelectItem value="completed">Verified / completed</SelectItem>
                  <SelectItem value="failed">Failed / refunded</SelectItem>
                </SelectContent>
              </Select>
              <div className="mt-4 space-y-2">
                {paymentRows?.map((o) => (
                  <Card key={o.id} className="border-border bg-card"><CardContent className="flex flex-wrap items-center gap-3 p-4 text-sm">
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">#{o.id} · <Link to={`/orders/${o.id}`} className="text-primary hover:underline">{o.orderNo}</Link></p>
                      <p className="text-xs text-muted-foreground">
                        {o.buyerName} → {o.sellerName}
                        {o.paymentMethod && <> · {o.paymentMethod.toUpperCase()}</>}
                        {o.transactionRef && <> · ref: <code className="font-mono">{o.transactionRef}</code></>}
                        {" · "}{fmtDate(o.createdAt)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-display font-bold">{inr(o.price)}</p>
                      <p className="text-xs text-muted-foreground">fee {inr(o.platformFee)}</p>
                    </div>
                    <Badge variant="outline" className={ORDER_STATUS[o.status]?.color}>{ORDER_STATUS[o.status]?.label}</Badge>
                    {o.paymentProof && (
                      <Dialog>
                        <DialogTrigger asChild><Button size="sm" variant="outline"><Eye className="mr-1 h-3.5 w-3.5" />Proof</Button></DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader><DialogTitle>Payment proof — {o.orderNo}</DialogTitle></DialogHeader>
                          <StorageImage storageKey={o.paymentProof} alt="Payment proof" className="max-h-[70vh] w-full rounded-lg object-contain" />
                        </DialogContent>
                      </Dialog>
                    )}
                  </CardContent></Card>
                ))}
                {!paymentRows?.length && <p className="text-sm text-muted-foreground">No payments in this view.</p>}
              </div>
            </div>
          )}

          {tab === "withdrawals" && (
            <div className="grid gap-6 lg:grid-cols-2">
              <div>
                <h2 className="mb-3 font-display text-lg font-semibold">Withdrawal requests</h2>
                <div className="space-y-2">
                  {wds?.map((w) => (
                    <Card key={w.id} className="border-border bg-card"><CardContent className="space-y-2 p-4 text-sm">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{w.userName}</span>
                        <span className="font-display font-bold text-primary">{inr(w.amount)}</span>
                        <Badge variant="outline" className={w.status === "approved" ? "text-primary" : w.status === "rejected" ? "text-destructive" : "text-amber-400"}>{w.status}</Badge>
                        <span className="ml-auto text-xs text-muted-foreground">{fmtDate(w.createdAt)}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{w.userEmail} · {w.method.toUpperCase()} → <code className="font-mono">{w.destination}</code></p>
                      {w.adminNote && <p className="text-xs text-muted-foreground">Note: {w.adminNote}</p>}
                      {w.status === "pending" && (
                        <div className="flex gap-1.5">
                          <Button size="sm" onClick={() => { setWdNote({ id: w.id, approve: true }); setWdNoteText(""); }}>Approve &amp; mark paid</Button>
                          <Button size="sm" variant="outline" className="text-destructive" onClick={() => { setWdNote({ id: w.id, approve: false }); setWdNoteText(""); }}>Reject &amp; refund</Button>
                        </div>
                      )}
                    </CardContent></Card>
                  ))}
                  {!wds?.length && <p className="text-sm text-muted-foreground">No withdrawal requests.</p>}
                </div>
                <Dialog open={wdNote != null} onOpenChange={(o) => { if (!o) setWdNote(null); }}>
                  <DialogContent>
                    <DialogHeader><DialogTitle>{wdNote?.approve ? "Approve withdrawal" : "Reject withdrawal"}</DialogTitle></DialogHeader>
                    <Textarea
                      placeholder={wdNote?.approve ? "Note (optional) — e.g. payout reference…" : "Rejection reason (shown to seller)…"}
                      value={wdNoteText}
                      onChange={(e) => setWdNoteText(e.target.value)}
                    />
                    <Button
                      variant={wdNote?.approve ? "default" : "destructive"}
                      disabled={processWd.isPending || (!wdNote?.approve && wdNoteText.trim().length < 3)}
                      onClick={() => wdNote && processWd.mutate({ id: wdNote.id, approve: wdNote.approve, note: wdNoteText.trim() || undefined })}
                    >
                      {wdNote?.approve ? "Approve & mark paid" : "Reject & refund balance"}
                    </Button>
                  </DialogContent>
                </Dialog>
              </div>
              <div>
                <h2 className="mb-3 font-display text-lg font-semibold">Seller balances</h2>
                <div className="space-y-2">
                  {balances?.filter((b) => Number(b.totalEarnings) > 0 || Number(b.availableBalance) > 0).map((b) => (
                    <div key={b.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-card p-3 text-sm">
                      <span className="font-medium">{b.userName}</span>
                      <span className="text-xs text-muted-foreground">{b.userEmail}</span>
                      <span className="ml-auto text-primary">{inr(b.availableBalance)}</span>
                      <span className="text-xs text-muted-foreground">earned {inr(b.totalEarnings)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === "disputes" && (
            <div className="space-y-3">
              {disputesList?.map((d) => (
                <Card key={d.id} className="border-border bg-card"><CardContent className="space-y-3 p-4 text-sm">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link to={`/orders/${d.orderId}`} className="font-medium text-primary hover:underline">{d.orderNo}</Link>
                    <span className="text-muted-foreground">opened by {d.openerName}</span>
                    <Badge variant="outline" className={d.status === "resolved" ? "text-primary" : "text-orange-400"}>{d.status}{d.resolution ? ` → ${d.resolution}` : ""}</Badge>
                    <span className="ml-auto text-xs text-muted-foreground">{fmtDate(d.createdAt)}</span>
                  </div>
                  <p>{d.reason}</p>
                  {d.openerEvidence && <StorageImage storageKey={d.openerEvidence} alt="evidence" className="max-h-40 rounded-lg border border-border object-contain" />}
                  {d.response && <p className="text-muted-foreground"><span className="text-foreground">Response:</span> {d.response}</p>}
                  {d.status !== "resolved" && (
                    <div className="flex flex-wrap gap-1.5">
                      {(["refund", "complete", "cancel"] as const).map((r) => (
                        <Button key={r} size="sm" variant={r === "refund" ? "default" : "outline"} onClick={() => { const note = prompt(`Admin note for "${r}":`); if (note) resolveDispute.mutate({ disputeId: d.id, resolution: r, note }); }}>
                          {r === "refund" ? "Refund buyer" : r === "complete" ? "Complete (pay seller)" : "Cancel order"}
                        </Button>
                      ))}
                      <Button size="sm" variant="secondary" asChild><Link to={`/orders/${d.orderId}`}>Open deal room</Link></Button>
                    </div>
                  )}
                  {d.adminNote && <p className="text-xs text-muted-foreground">Admin: {d.adminNote}</p>}
                </CardContent></Card>
              ))}
              {!disputesList?.length && <p className="text-sm text-muted-foreground">No disputes.</p>}
            </div>
          )}

          {tab === "games" && (
            <div>
              <div className="flex gap-2">
                <Input placeholder="New game name…" value={gameName} onChange={(e) => setGameName(e.target.value)} className="max-w-xs" />
                <Button disabled={gameName.trim().length < 2 || saveGame.isPending} onClick={() => saveGame.mutate({ name: gameName.trim(), status: "active", sortOrder: (allGames?.length ?? 0) + 1 })}>Add game</Button>
              </div>
              <div className="mt-4 space-y-2">
                {allGames?.map((g) => (
                  <div key={g.id} className="flex items-center gap-3 rounded-lg border border-border bg-card p-3 text-sm">
                    <span className="font-medium">{g.name}</span>
                    <Badge variant="outline" className={g.status === "active" ? "text-primary" : "text-muted-foreground"}>{g.status}</Badge>
                    <div className="ml-auto flex gap-1.5">
                      {g.status === "active"
                        ? <Button size="sm" variant="outline" onClick={() => saveGame.mutate({ id: g.id, name: g.name, status: "inactive", sortOrder: g.sortOrder })}>Deactivate</Button>
                        : <Button size="sm" variant="outline" onClick={() => saveGame.mutate({ id: g.id, name: g.name, status: "active", sortOrder: g.sortOrder })}>Activate</Button>}
                      <Button size="sm" variant="ghost" className="text-destructive" onClick={() => { if (confirm(`Remove ${g.name}?`)) deleteGame.mutate({ id: g.id }); }}>Remove</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "settings" && sf && (
            <div className="grid max-w-3xl gap-6">
              <Card className="border-border bg-card"><CardContent className="space-y-4 p-5">
                <h3 className="font-display font-semibold">Marketplace</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Platform fee (%)</Label>
                    <Input value={sf.platformFeePercent} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, platformFeePercent: e.target.value }))} />
                    <p className="text-xs text-muted-foreground">Calculated server-side on every completed order. Example: ₹1,000 → ₹50 fee → seller ₹950.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Minimum withdrawal (₹)</Label>
                    <Input value={sf.minWithdrawal} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, minWithdrawal: e.target.value }))} />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch checked={sf.listingsEnabled === "true"} onCheckedChange={(v) => setSettingsForm(JSON.stringify({ ...sf, listingsEnabled: v ? "true" : "false" }))} />
                  <Label>Allow new listings</Label>
                </div>
                <div className="flex items-center gap-3">
                  <Switch checked={sf.withdrawalsEnabled === "true"} onCheckedChange={(v) => setSettingsForm(JSON.stringify({ ...sf, withdrawalsEnabled: v ? "true" : "false" }))} />
                  <Label>Allow withdrawal requests</Label>
                </div>
                <div className="flex items-center gap-3">
                  <Switch checked={sf.listingAutoApprove === "true"} onCheckedChange={(v) => setSettingsForm(JSON.stringify({ ...sf, listingAutoApprove: v ? "true" : "false" }))} />
                  <Label>Auto-approve new listings</Label>
                </div>
                <div className="space-y-1.5">
                  <Label>Marketplace notice</Label>
                  <Input value={sf.marketplaceNotice} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, marketplaceNotice: e.target.value }))} />
                </div>
              </CardContent></Card>
              <Card className="border-border bg-card"><CardContent className="space-y-4 p-5">
                <h3 className="font-display font-semibold">Payment methods</h3>
                {(["upi", "airtel", "crypto"] as const).map((k) => (
                  <div key={k} className="space-y-2 rounded-lg border border-border p-4">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={sf.paymentMethods[k].enabled}
                        onCheckedChange={(v) => setSettingsForm(JSON.stringify({ ...sf, paymentMethods: { ...sf.paymentMethods, [k]: { ...sf.paymentMethods[k], enabled: v } } }))}
                      />
                      <Input className="max-w-40" value={sf.paymentMethods[k].label} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, paymentMethods: { ...sf.paymentMethods, [k]: { ...sf.paymentMethods[k], label: e.target.value } } }))} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>{k === "crypto" ? "Wallet address" : "Payment ID / VPA"}</Label>
                      <Input className="font-mono text-sm" value={sf.paymentMethods[k].details} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, paymentMethods: { ...sf.paymentMethods, [k]: { ...sf.paymentMethods[k], details: e.target.value } } }))} />
                    </div>
                    {k === "crypto" && (
                      <div className="space-y-1.5">
                        <Label>Network / token info</Label>
                        <Input value={sf.paymentMethods.crypto.network ?? ""} onChange={(e) => setSettingsForm(JSON.stringify({ ...sf, paymentMethods: { ...sf.paymentMethods, crypto: { ...sf.paymentMethods.crypto, network: e.target.value } } }))} />
                      </div>
                    )}
                  </div>
                ))}
              </CardContent></Card>
              {saveSettings.error && <p className="text-sm text-destructive">{saveSettings.error.message}</p>}
              <Button className="w-fit" disabled={saveSettings.isPending} onClick={() => saveSettings.mutate(sf)}>
                {saveSettings.isPending ? "Saving…" : saveSettings.isSuccess ? "Saved ✓" : "Save settings"}
              </Button>
            </div>
          )}

          {tab === "audit" && (
            <div className="grid gap-6 lg:grid-cols-2">
              <div>
                <h2 className="mb-3 font-display text-lg font-semibold">Admin activity log</h2>
                <div className="space-y-1.5">
                  {logs?.map((l) => (
                    <div key={l.id} className="rounded-lg border border-border bg-card p-3 text-xs">
                      <span className="font-mono text-primary">{l.action}</span>
                      <span className="text-muted-foreground"> · {l.targetType} #{l.targetId} · admin#{l.adminId} · {fmtDate(l.createdAt)}</span>
                      {l.detail && <p className="mt-0.5 text-muted-foreground">{l.detail}</p>}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h2 className="mb-3 font-display text-lg font-semibold">Credential access log</h2>
                <div className="space-y-1.5">
                  {credLogs?.map((l) => (
                    <div key={l.id} className="rounded-lg border border-border bg-card p-3 text-xs text-muted-foreground">
                      {l.adminName} viewed credentials for order #{l.orderId} (listing #{l.listingId}) · {fmtDate(l.createdAt)}
                    </div>
                  ))}
                  {!credLogs?.length && <p className="text-sm text-muted-foreground">No credential access yet.</p>}
                </div>
              </div>
            </div>
          )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
